# GeneGap report template

**DRAFT — human review is required before final export.**

Run: report-template

These findings are research hypotheses for expert review. They are not individual genotype interpretations, treatment recommendations, or dosing advice.

Recorded approvals cover the findings and their cited source records. The report title and any additional context notes are supplied by the report author.

## Findings

No findings supplied.

## Limits and assumptions

Self-identified trial race and ethnicity and genetic ancestry are different measures. Their mapping is an explicit assumption.

Carrier estimates do not predict individual drug response. Missing evidence does not establish safety.

Report author's context notes (outside per-finding approval):

- This is an empty draft template. No analysis or human review has been completed.

- Agent output and critic results must be connected before findings can be approved.

- Ancestry mapping weights and target-population shares currently include placeholders that need medical review.
