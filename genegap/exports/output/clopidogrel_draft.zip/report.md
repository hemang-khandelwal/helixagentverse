# GeneGap draft coverage analysis: clopidogrel

**DRAFT — human review is required before final export.**

Run: run-0b86b3c9fe5a479cbf434dcf35f2304b

These findings are research hypotheses for expert review. They are not individual genotype interpretations, treatment recommendations, or dosing advice.

Recorded approvals cover the findings and their cited source records. The report title and any additional context notes are supplied by the report author.

## Findings

### Variant 10-94781859-G-A

For clopidogrel, trial coverage of CYP2C19 rs4244285 in group amr suggests lower expected-carrier representation under mappings A, B and C, subject to mapping and target-population denominator assumptions. This is a draft coverage hypothesis.

Evidence tier: Not graded.

Citations: None supplied.

Mapping robustness: Reported as surviving all evaluated mappings.

Review status: draft.
No human review is recorded for this version of the finding.

Supporting source records:

**Fact F-e77c3dc56ed5 — ac\_an:afr**

```json
{"ac": 11987, "an": 67188, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.796834+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-fd96593d59de — ac\_an:ami**

```json
{"ac": 166, "an": 910, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.797445+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-9c590cde7fac — ac\_an:amr**

```json
{"ac": 4023, "an": 34880, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.798177+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-62e788dbfd9a — ac\_an:asj**

```json
{"ac": 3323, "an": 25098, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.798601+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-a8b8cb8c25ab — ac\_an:eas**

```json
{"ac": 11167, "an": 36782, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799010+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-17fdaf953b67 — ac\_an:fin**

```json
{"ac": 10733, "an": 61354, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799498+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-bbf212e3af8a — ac\_an:mid**

```json
{"ac": 611, "an": 5608, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799908+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-2386f33e2c84 — ac\_an:nfe**

```json
{"ac": 162522, "an": 1111304, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.800317+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-9b20fe7bdc51 — ac\_an:remaining**

```json
{"ac": 9207, "an": 56126, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.800811+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-ed42d2d17eeb — ac\_an:sas**

```json
{"ac": 20947, "an": 65396, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.801247+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-195ad34b1e99 — classification**

```json
{"classification": "drug response", "title": "NM_000769.4(CYP2C19):c.681G>T (p.Pro227=)"}
```

Source: ClinVar; record: VCV/uid:1703261; method: api; retrieved: 2026-11-08T13:30:44.802021+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/1703261/>)

**Fact F-f7a5bdb65dd2 — classification**

```json
{"classification": "drug response", "title": "CYP2C19*2/*2"}
```

Source: ClinVar; record: VCV/uid:638797; method: api; retrieved: 2026-11-08T13:30:44.802401+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/638797/>)

**Fact F-25ce0d369075 — classification**

```json
{"classification": "drug response", "title": "CYP2C19*2/*23"}
```

Source: ClinVar; record: VCV/uid:634407; method: api; retrieved: 2026-11-08T13:30:44.802776+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/634407/>)

**Fact F-4e63fd24c36c — overall\_status**

```json
"COMPLETED"
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.786117+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842>)

**Fact F-d661bf8179ea — baseline:sex:Female**

```json
{"basis": "total_row", "count": 287}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.788823+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-f4fb328ee136 — baseline:sex:Male**

```json
{"basis": "total_row", "count": 14286}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.789267+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-0ded459e81e8 — baseline:race:American Indian or Alaska Native**

```json
{"basis": "total_row", "count": 146}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.789751+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-351ee3cb9cd5 — baseline:race:Asian**

```json
{"basis": "total_row", "count": 40}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.790226+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-49d7e83055ff — baseline:race:Native Hawaiian or Other Pacific Islander**

```json
{"basis": "total_row", "count": 123}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.790659+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-440224b7c4ce — baseline:race:Black or African American**

```json
{"basis": "total_row", "count": 2329}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791146+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-997b44cb3a84 — baseline:race:White**

```json
{"basis": "total_row", "count": 11935}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791574+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-ed3f57076aa8 — baseline:race:More than one race**

```json
{"basis": "total_row", "count": 0}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791995+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-4eb5e4253bfb — baseline:race:Unknown or Not Reported**

```json
{"basis": "total_row", "count": 0}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.792509+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-c4dd55286720 — pooled\_race\_counts**

```json
{"counts": {"American Indian or Alaska Native": 146, "Asian": 40, "Black or African American": 2329, "More than one race": 0, "Native Hawaiian or Other Pacific Islander": 123, "Unknown or Not Reported": 0, "White": 11935}, "fact_ids": ["F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb"], "nct_ids": ["NCT01609842"]}
```

Source: GeneGap.trials; record: run-0b86b3c9fe5a479cbf434dcf35f2304b; method: computed; retrieved: 2026-11-08T13:30:44.793280+00:00.

Source URL not provided.

Source note: Found 3 completed trials with results; reading the first 3. NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939). NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076). 1 of 1 trials report a race breakdown.

**Fact F-f9d3360d4f0d — gene\_rule**

```json
{"assessable": true, "function_note": "Variant list comes from config/variant_details_CYP2C19.csv (medical student)", "gene": "CYP2C19", "inheritance": "dominant", "min_af": 0.005, "min_an": 5000, "reason_if_not": "", "rsids": [], "source": "https://www.ncbi.nlm.nih.gov/books/NBK84114/table/clopidogrel.Te/", "verified_by": "medical student (variant_details_CYP2C19.csv)"}
```

Source: GeneGap.variants; record: CYP2C19; method: curated; retrieved: 2026-11-08T13:30:44.803567+00:00.

Source URL not provided.

Source note: Variant list comes from config/variant\_details\_CYP2C19.csv (medical student)

**Fact F-c8651cb724b1 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure. Must be replaced with a national registry or audit before any result is reported.", "geography": "United States", "gnomad_group": "nfe", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.6, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:nfe; method: curated; retrieved: 2026-11-08T13:30:44.750284+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. Must be replaced with a national registry or audit before any result is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-d918cfb0b6c1 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "afr", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.13, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:afr; method: curated; retrieved: 2026-11-08T13:30:44.750935+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-b6971ee78767 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "amr", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.18, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:amr; method: curated; retrieved: 2026-11-08T13:30:44.751397+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-0162d73c2d7b — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "eas", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.05, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:eas; method: curated; retrieved: 2026-11-08T13:30:44.751852+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-39108d870da2 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "sas", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.02, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:sas; method: curated; retrieved: 2026-11-08T13:30:44.752290+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-7060fef065dd — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "remaining", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.02, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:remaining; method: curated; retrieved: 2026-11-08T13:30:44.752821+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-a94597d8f0fa — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "afr", "rationale": "Conservative 1-to-1 mapping of trial Black/African American participants to gnomAD African/African American genetic ancestry group", "source": "gnomAD v4 ancestry definitions", "trial_category": "Black or African American", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:0; method: curated; retrieved: 2026-11-08T13:30:44.753275+00:00.

Source URL not provided.

Source note: Conservative 1-to-1 mapping of trial Black/African American participants to gnomAD African/African American genetic ancestry group

**Fact F-b119d67d1311 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "nfe", "rationale": "Conservative 1-to-1 mapping of trial White participants to gnomAD non-Finnish European genetic ancestry group", "source": "gnomAD v4 ancestry definitions", "trial_category": "White", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:1; method: curated; retrieved: 2026-11-08T13:30:44.753839+00:00.

Source URL not provided.

Source note: Conservative 1-to-1 mapping of trial White participants to gnomAD non-Finnish European genetic ancestry group

**Fact F-5366663e00fb — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "eas", "rationale": "In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics", "source": "CPIC Global Allele Frequency Data", "trial_category": "Asian", "weight": 0.6}
```

Source: GeneGap.mapping; record: A:2; method: curated; retrieved: 2026-11-08T13:30:44.754474+00:00.

Source URL not provided.

Source note: In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics

**Fact F-41d2fdc6e017 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "sas", "rationale": "In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics", "source": "CPIC Global Allele Frequency Data", "trial_category": "Asian", "weight": 0.4}
```

Source: GeneGap.mapping; record: A:3; method: curated; retrieved: 2026-11-08T13:30:44.755081+00:00.

Source URL not provided.

Source note: In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics

**Fact F-fdc78c982461 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "ami", "rationale": "Direct mapping to gnomAD Indigenous American ancestry group", "source": "gnomAD v4 Indigenous American cohort", "trial_category": "American Indian or Alaska Native", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:4; method: curated; retrieved: 2026-11-08T13:30:44.755617+00:00.

Source URL not provided.

Source note: Direct mapping to gnomAD Indigenous American ancestry group

**Fact F-a95fae356884 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Currently no isolated Pacific Islander cohort in gnomAD v4; mapped to remaining with low confidence flag", "source": "gnomAD v4 population groups", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:5; method: curated; retrieved: 2026-11-08T13:30:44.756114+00:00.

Source URL not provided.

Source note: Currently no isolated Pacific Islander cohort in gnomAD v4; mapped to remaining with low confidence flag

**Fact F-8c2993ee938b — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "amr", "rationale": "Admixed American population in gnomAD reflecting diverse Latin American and Hispanic ancestry", "source": "gnomAD v4 Admixed American definitions", "trial_category": "Hispanic or Latino", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:6; method: curated; retrieved: 2026-11-08T13:30:44.756629+00:00.

Source URL not provided.

Source note: Admixed American population in gnomAD reflecting diverse Latin American and Hispanic ancestry

**Fact F-33542d6ec3d4 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Mixed ancestry without specific proportions reported by trial; evaluated under admixture sensitivity model", "source": "gnomAD v4 population groups", "trial_category": "More than one race", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:7; method: curated; retrieved: 2026-11-08T13:30:44.757090+00:00.

Source URL not provided.

Source note: Mixed ancestry without specific proportions reported by trial; evaluated under admixture sensitivity model

**Fact F-7a175210b780 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic group. Tracked explicitly as missing trial demographic data", "source": "FDA Demographic Rule & GeneGap Missing Data Protocol", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: A:8; method: curated; retrieved: 2026-11-08T13:30:44.757475+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic group. Tracked explicitly as missing trial demographic data

**Fact F-f43aff3f7e20 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "afr", "rationale": "Admixture-aware version: most US participants identifying as Black or African American carry substantial non-African ancestry. Weight is a structural placeholder until a cited study replaces it.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Black or African American", "weight": 0.85}
```

Source: GeneGap.mapping; record: B:0; method: curated; retrieved: 2026-11-08T13:30:44.757905+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: most US participants identifying as Black or African American carry substantial non-African ancestry. Weight is a structural placeholder until a cited study replaces it.

**Fact F-9a046df0939e — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "nfe", "rationale": "Residual European ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Black or African American", "weight": 0.15}
```

Source: GeneGap.mapping; record: B:1; method: curated; retrieved: 2026-11-08T13:30:44.758399+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Residual European ancestry component. Placeholder weight.

**Fact F-ee9a7718f927 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "nfe", "rationale": "Admixture-aware version: participants identifying as White are not exclusively non-Finnish European. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.9}
```

Source: GeneGap.mapping; record: B:2; method: curated; retrieved: 2026-11-08T13:30:44.758965+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: participants identifying as White are not exclusively non-Finnish European. Placeholder weight.

**Fact F-7c09e76d1fc2 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "fin", "rationale": "Finnish ancestry is reported separately by gnomAD. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.03}
```

Source: GeneGap.mapping; record: B:3; method: curated; retrieved: 2026-11-08T13:30:44.759425+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Finnish ancestry is reported separately by gnomAD. Placeholder weight.

**Fact F-adf9cf9e266d — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "asj", "rationale": "Ashkenazi Jewish ancestry is reported separately by gnomAD. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.04}
```

Source: GeneGap.mapping; record: B:4; method: curated; retrieved: 2026-11-08T13:30:44.759856+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Ashkenazi Jewish ancestry is reported separately by gnomAD. Placeholder weight.

**Fact F-a4273d3aa3e2 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "mid", "rationale": "Middle Eastern ancestry is frequently recorded as White on US trial forms. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.03}
```

Source: GeneGap.mapping; record: B:5; method: curated; retrieved: 2026-11-08T13:30:44.760419+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Middle Eastern ancestry is frequently recorded as White on US trial forms. Placeholder weight.

**Fact F-5d2928aa7dc3 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "eas", "rationale": "Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.", "source": "PLACEHOLDER - needs trial-country breakdown ([MED] D2)", "trial_category": "Asian", "weight": 0.5}
```

Source: GeneGap.mapping; record: B:6; method: curated; retrieved: 2026-11-08T13:30:44.760865+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.

**Fact F-1f6ef9380535 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "sas", "rationale": "Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.", "source": "PLACEHOLDER - needs trial-country breakdown ([MED] D2)", "trial_category": "Asian", "weight": 0.5}
```

Source: GeneGap.mapping; record: B:7; method: curated; retrieved: 2026-11-08T13:30:44.761284+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.

**Fact F-17d94a8d44d3 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "ami", "rationale": "Admixture-aware version: gnomAD ami is an Amish cohort and is a poor proxy. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.7}
```

Source: GeneGap.mapping; record: B:8; method: curated; retrieved: 2026-11-08T13:30:44.761784+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: gnomAD ami is an Amish cohort and is a poor proxy. Placeholder weight.

**Fact F-f59a2d816c6b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Part of this category is better represented by the Admixed American group. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.3}
```

Source: GeneGap.mapping; record: B:9; method: curated; retrieved: 2026-11-08T13:30:44.762276+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Part of this category is better represented by the Admixed American group. Placeholder weight.

**Fact F-8b6143337b21 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "gnomAD v4 has no Pacific Islander group. Placeholder weight.", "source": "PLACEHOLDER - no Pacific Islander cohort in gnomAD v4", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.7}
```

Source: GeneGap.mapping; record: B:10; method: curated; retrieved: 2026-11-08T13:30:44.762760+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. gnomAD v4 has no Pacific Islander group. Placeholder weight.

**Fact F-f6b9a1a71532 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Partial East Asian ancestry component. Placeholder weight.", "source": "PLACEHOLDER - no Pacific Islander cohort in gnomAD v4", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.3}
```

Source: GeneGap.mapping; record: B:11; method: curated; retrieved: 2026-11-08T13:30:44.763386+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Partial East Asian ancestry component. Placeholder weight.

**Fact F-75971e836a89 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "amr", "rationale": "Hispanic or Latino ancestry is highly variable; this version keeps most weight on amr with European and African components. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.8}
```

Source: GeneGap.mapping; record: B:12; method: curated; retrieved: 2026-11-08T13:30:44.764002+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Hispanic or Latino ancestry is highly variable; this version keeps most weight on amr with European and African components. Placeholder weight.

**Fact F-6193346a98a0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "European ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.12}
```

Source: GeneGap.mapping; record: B:13; method: curated; retrieved: 2026-11-08T13:30:44.764545+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. European ancestry component. Placeholder weight.

**Fact F-1a4d8290645f — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "African ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.08}
```

Source: GeneGap.mapping; record: B:14; method: curated; retrieved: 2026-11-08T13:30:44.764987+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. African ancestry component. Placeholder weight.

**Fact F-d801b8e299d8 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Mixed ancestry with unreported components. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.6}
```

Source: GeneGap.mapping; record: B:15; method: curated; retrieved: 2026-11-08T13:30:44.765418+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Mixed ancestry with unreported components. Placeholder weight.

**Fact F-4838901c32e5 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Admixed American component. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: B:16; method: curated; retrieved: 2026-11-08T13:30:44.765931+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixed American component. Placeholder weight.

**Fact F-d999ffd4f514 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "European component. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: B:17; method: curated; retrieved: 2026-11-08T13:30:44.766389+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. European component. Placeholder weight.

**Fact F-90de285fe388 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.", "source": "GeneGap missing-data protocol (D2)", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: B:18; method: curated; retrieved: 2026-11-08T13:30:44.766852+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.

**Fact F-dff1c8538733 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test: widest plausible spread. These weights are not an estimate of reality; they exist to test whether a finding survives an extreme mapping.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.6}
```

Source: GeneGap.mapping; record: C:0; method: curated; retrieved: 2026-11-08T13:30:44.767287+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread. These weights are not an estimate of reality; they exist to test whether a finding survives an extreme mapping.

**Fact F-e4d3127bc88b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.25}
```

Source: GeneGap.mapping; record: C:1; method: curated; retrieved: 2026-11-08T13:30:44.767700+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-49fdc419d2a9 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.15}
```

Source: GeneGap.mapping; record: C:2; method: curated; retrieved: 2026-11-08T13:30:44.768272+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e3de003f2136 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test: widest plausible spread.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.7}
```

Source: GeneGap.mapping; record: C:3; method: curated; retrieved: 2026-11-08T13:30:44.768937+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread.

**Fact F-ac3792b4a7d0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "fin", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:4; method: curated; retrieved: 2026-11-08T13:30:44.769531+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e5a7d9e1fc49 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "asj", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:5; method: curated; retrieved: 2026-11-08T13:30:44.770060+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-aaabaaad3c9c — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "mid", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:6; method: curated; retrieved: 2026-11-08T13:30:44.770624+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-12a72f5fa447 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test: the opposite extreme to version A's 60/40 East Asian split.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Asian", "weight": 0.25}
```

Source: GeneGap.mapping; record: C:7; method: curated; retrieved: 2026-11-08T13:30:44.771462+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: the opposite extreme to version A's 60/40 East Asian split.

**Fact F-f3172b718bcb — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "sas", "rationale": "Stress test: South Asian dominant split.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Asian", "weight": 0.75}
```

Source: GeneGap.mapping; record: C:8; method: curated; retrieved: 2026-11-08T13:30:44.771918+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: South Asian dominant split.

**Fact F-47394cb233fd — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test: treats the category as predominantly Admixed American.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.8}
```

Source: GeneGap.mapping; record: C:9; method: curated; retrieved: 2026-11-08T13:30:44.772363+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: treats the category as predominantly Admixed American.

**Fact F-bf0ade33b67b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "ami", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:10; method: curated; retrieved: 2026-11-08T13:30:44.772800+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-85f9336dd5c1 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test: no Pacific Islander cohort exists in gnomAD v4.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:11; method: curated; retrieved: 2026-11-08T13:30:44.773227+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: no Pacific Islander cohort exists in gnomAD v4.

**Fact F-af3c66ea9892 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:12; method: curated; retrieved: 2026-11-08T13:30:44.773618+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-0a32bf99a858 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test: widest plausible spread for a highly variable category.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:13; method: curated; retrieved: 2026-11-08T13:30:44.774018+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread for a highly variable category.

**Fact F-1a6c8ab011f0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.3}
```

Source: GeneGap.mapping; record: C:14; method: curated; retrieved: 2026-11-08T13:30:44.774437+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-87dcbbed9441 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:15; method: curated; retrieved: 2026-11-08T13:30:44.774914+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-7cfdc0a2f9cf — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Stress test: components are never reported by trials.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.4}
```

Source: GeneGap.mapping; record: C:16; method: curated; retrieved: 2026-11-08T13:30:44.775326+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: components are never reported by trials.

**Fact F-458dc3231028 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:17; method: curated; retrieved: 2026-11-08T13:30:44.775728+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e43a3c3322e9 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:18; method: curated; retrieved: 2026-11-08T13:30:44.776150+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-b1e7afd8ad51 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:19; method: curated; retrieved: 2026-11-08T13:30:44.776588+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-fde7721260bc — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.", "source": "GeneGap missing-data protocol (D2)", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: C:20; method: curated; retrieved: 2026-11-08T13:30:44.777095+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.

**Fact F-c8a8636a7338 — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The trial data maps nobody to: amr, although the target population includes these groups.", "The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 1.26750658501581, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 1.2293546020300978, "expected_carriers": 756.9007805485037, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 2329.0, "prob_fewer_than_k": 0.0, "required_n": 93, "target_share": 0.13, "trial_share": 0.15981609826391271}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 146.0, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.010018527413710286}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.0, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.0, "expected_carriers": 0.0, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 139, "target_share": 0.18, "trial_share": 0.0}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 122, "target_share": null, "trial_share": 0.0}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.033959815759977044, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.03293762437384203, "expected_carriers": 12.360635146352273, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 24.0, "prob_fewer_than_k": 0.12121717438131821, "required_n": 59, "target_share": 0.05, "trial_share": 0.0016468812186921018}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 94, "target_share": null, "trial_share": 0.0}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 146, "target_share": null, "trial_share": 0.0}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.4073277815809935, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.3649671767423774, "expected_carriers": 3235.595160158267, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 11935.0, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.8189803060454265}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.435110139424706, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.42201331228985106, "expected_carriers": 37.04435132112077, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 123.0, "prob_fewer_than_k": 5.906693209093745e-10, "required_n": 100, "target_share": 0.02, "trial_share": 0.008440266245797022}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.05659969293329508, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.054896040623070054, "expected_carriers": 8.6083464703541, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 16.0, "prob_fewer_than_k": 0.6699441424150812, "required_n": 56, "target_share": 0.02, "trial_share": 0.0010979208124614012}], "inheritance": "dominant", "mapping_version": "A", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:A; method: computed; retrieved: 2026-11-08T13:30:44.811505+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The trial data maps nobody to: amr, although the target population includes these groups. The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-26bb9eb5dc88 — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 1.0823908937957165, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 1.0449514117255831, "expected_carriers": 643.365663466228, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 1979.6499999999999, "prob_fewer_than_k": 0.0, "required_n": 93, "target_share": 0.13, "trial_share": 0.13584368352432583}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 102.19999999999999, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.007012969189597201}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.017295800742759836, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.016697545689517146, "expected_carriers": 9.52096724631897, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 43.8, "prob_fewer_than_k": 0.5045692213261437, "required_n": 139, "target_share": 0.18, "trial_share": 0.003005558224113086}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 118.04763112422721, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 477.40000000000003, "prob_fewer_than_k": 2.2135395426542072e-45, "required_n": 122, "target_share": null, "trial_share": 0.03275921224181706}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.08088748456956449, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.07808961778631716, "expected_carriers": 29.305005826143514, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 56.9, "prob_fewer_than_k": 2.265639199866795e-08, "required_n": 59, "target_share": 0.05, "trial_share": 0.0039044808893158585}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 114.31418240472257, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 358.05, "prob_fewer_than_k": 4.481323492858098e-46, "required_n": 94, "target_share": null, "trial_share": 0.024569409181362797}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 73.7699605550635, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 358.05, "prob_fewer_than_k": 1.9162976424687183e-24, "required_n": 146, "target_share": null, "trial_share": 0.024569409181362797}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.3138707648482049, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.2684244836341183, "expected_carriers": 3006.7449168027915, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 11090.85, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.7610546901804709}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.3059935158804703, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.29540931860289577, "expected_carriers": 25.93104592478454, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 86.1, "prob_fewer_than_k": 1.3105166257994806e-05, "required_n": 100, "target_share": 0.02, "trial_share": 0.005908186372057916}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.07107863318942398, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.0686200507788376, "expected_carriers": 10.760433087942625, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 20.0, "prob_fewer_than_k": 0.28517164570263553, "required_n": 56, "target_share": 0.02, "trial_share": 0.0013724010155767518}], "inheritance": "dominant", "mapping_version": "B", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:B; method: computed; retrieved: 2026-11-08T13:30:44.818267+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-c4ed1377c5ff — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 0.775577213269676, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 0.7376127612180586, "expected_carriers": 454.1404683291022, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 1397.3999999999999, "prob_fewer_than_k": 2.7003141966092542e-219, "required_n": 93, "target_share": 0.13, "trial_share": 0.09588965895834763}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 29.200000000000003, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.0020037054827420574}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.18685332814725658, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.17770687039197297, "expected_carriers": 101.32874159524174, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 466.15, "prob_fewer_than_k": 6.962854051221955e-37, "required_n": 139, "target_share": 0.18, "trial_share": 0.031987236670555134}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 295.119077810568, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 3.0548698977556544e-130, "required_n": 122, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.10317718902735995, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.09812667261373774, "expected_carriers": 36.824392206841146, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 71.5, "prob_fewer_than_k": 3.955338797572064e-12, "required_n": 59, "target_share": 0.05, "trial_share": 0.004906333630686887}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 381.04727468240856, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 5.505619853235287e-181, "required_n": 94, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 245.89986851687834, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 1.67727965034696e-103, "required_n": 146, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.0746721958511178, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.0220670646629613, "expected_carriers": 2422.765399878039, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 8936.75, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.6132402387977767}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.22186703234904326, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.21100665614492553, "expected_carriers": 18.522175660560386, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 61.5, "prob_fewer_than_k": 0.0036565532051273213, "required_n": 100, "target_share": 0.02, "trial_share": 0.004220133122898511}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.10822782065806989, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.10293007616825638, "expected_carriers": 16.140649631913938, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 30.0, "prob_fewer_than_k": 0.007288996623613486, "required_n": 56, "target_share": 0.02, "trial_share": 0.0020586015233651275}], "inheritance": "dominant", "mapping_version": "C", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:C; method: computed; retrieved: 2026-11-08T13:30:44.825122+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

### Variant 10-94781859-G-A

For clopidogrel, trial coverage of CYP2C19 rs4244285 in group eas suggests lower expected-carrier representation under mappings A, B and C, subject to mapping and target-population denominator assumptions. This is a draft coverage hypothesis.

Evidence tier: Not graded.

Citations: None supplied.

Mapping robustness: Reported as surviving all evaluated mappings.

Review status: draft.
No human review is recorded for this version of the finding.

Supporting source records:

**Fact F-e77c3dc56ed5 — ac\_an:afr**

```json
{"ac": 11987, "an": 67188, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.796834+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-fd96593d59de — ac\_an:ami**

```json
{"ac": 166, "an": 910, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.797445+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-9c590cde7fac — ac\_an:amr**

```json
{"ac": 4023, "an": 34880, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.798177+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-62e788dbfd9a — ac\_an:asj**

```json
{"ac": 3323, "an": 25098, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.798601+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-a8b8cb8c25ab — ac\_an:eas**

```json
{"ac": 11167, "an": 36782, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799010+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-17fdaf953b67 — ac\_an:fin**

```json
{"ac": 10733, "an": 61354, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799498+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-bbf212e3af8a — ac\_an:mid**

```json
{"ac": 611, "an": 5608, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799908+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-2386f33e2c84 — ac\_an:nfe**

```json
{"ac": 162522, "an": 1111304, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.800317+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-9b20fe7bdc51 — ac\_an:remaining**

```json
{"ac": 9207, "an": 56126, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.800811+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-ed42d2d17eeb — ac\_an:sas**

```json
{"ac": 20947, "an": 65396, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.801247+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-195ad34b1e99 — classification**

```json
{"classification": "drug response", "title": "NM_000769.4(CYP2C19):c.681G>T (p.Pro227=)"}
```

Source: ClinVar; record: VCV/uid:1703261; method: api; retrieved: 2026-11-08T13:30:44.802021+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/1703261/>)

**Fact F-f7a5bdb65dd2 — classification**

```json
{"classification": "drug response", "title": "CYP2C19*2/*2"}
```

Source: ClinVar; record: VCV/uid:638797; method: api; retrieved: 2026-11-08T13:30:44.802401+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/638797/>)

**Fact F-25ce0d369075 — classification**

```json
{"classification": "drug response", "title": "CYP2C19*2/*23"}
```

Source: ClinVar; record: VCV/uid:634407; method: api; retrieved: 2026-11-08T13:30:44.802776+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/634407/>)

**Fact F-4e63fd24c36c — overall\_status**

```json
"COMPLETED"
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.786117+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842>)

**Fact F-d661bf8179ea — baseline:sex:Female**

```json
{"basis": "total_row", "count": 287}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.788823+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-f4fb328ee136 — baseline:sex:Male**

```json
{"basis": "total_row", "count": 14286}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.789267+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-0ded459e81e8 — baseline:race:American Indian or Alaska Native**

```json
{"basis": "total_row", "count": 146}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.789751+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-351ee3cb9cd5 — baseline:race:Asian**

```json
{"basis": "total_row", "count": 40}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.790226+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-49d7e83055ff — baseline:race:Native Hawaiian or Other Pacific Islander**

```json
{"basis": "total_row", "count": 123}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.790659+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-440224b7c4ce — baseline:race:Black or African American**

```json
{"basis": "total_row", "count": 2329}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791146+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-997b44cb3a84 — baseline:race:White**

```json
{"basis": "total_row", "count": 11935}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791574+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-ed3f57076aa8 — baseline:race:More than one race**

```json
{"basis": "total_row", "count": 0}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791995+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-4eb5e4253bfb — baseline:race:Unknown or Not Reported**

```json
{"basis": "total_row", "count": 0}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.792509+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-c4dd55286720 — pooled\_race\_counts**

```json
{"counts": {"American Indian or Alaska Native": 146, "Asian": 40, "Black or African American": 2329, "More than one race": 0, "Native Hawaiian or Other Pacific Islander": 123, "Unknown or Not Reported": 0, "White": 11935}, "fact_ids": ["F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb"], "nct_ids": ["NCT01609842"]}
```

Source: GeneGap.trials; record: run-0b86b3c9fe5a479cbf434dcf35f2304b; method: computed; retrieved: 2026-11-08T13:30:44.793280+00:00.

Source URL not provided.

Source note: Found 3 completed trials with results; reading the first 3. NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939). NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076). 1 of 1 trials report a race breakdown.

**Fact F-f9d3360d4f0d — gene\_rule**

```json
{"assessable": true, "function_note": "Variant list comes from config/variant_details_CYP2C19.csv (medical student)", "gene": "CYP2C19", "inheritance": "dominant", "min_af": 0.005, "min_an": 5000, "reason_if_not": "", "rsids": [], "source": "https://www.ncbi.nlm.nih.gov/books/NBK84114/table/clopidogrel.Te/", "verified_by": "medical student (variant_details_CYP2C19.csv)"}
```

Source: GeneGap.variants; record: CYP2C19; method: curated; retrieved: 2026-11-08T13:30:44.803567+00:00.

Source URL not provided.

Source note: Variant list comes from config/variant\_details\_CYP2C19.csv (medical student)

**Fact F-c8651cb724b1 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure. Must be replaced with a national registry or audit before any result is reported.", "geography": "United States", "gnomad_group": "nfe", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.6, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:nfe; method: curated; retrieved: 2026-11-08T13:30:44.750284+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. Must be replaced with a national registry or audit before any result is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-d918cfb0b6c1 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "afr", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.13, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:afr; method: curated; retrieved: 2026-11-08T13:30:44.750935+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-b6971ee78767 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "amr", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.18, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:amr; method: curated; retrieved: 2026-11-08T13:30:44.751397+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-0162d73c2d7b — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "eas", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.05, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:eas; method: curated; retrieved: 2026-11-08T13:30:44.751852+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-39108d870da2 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "sas", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.02, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:sas; method: curated; retrieved: 2026-11-08T13:30:44.752290+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-7060fef065dd — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "remaining", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.02, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:remaining; method: curated; retrieved: 2026-11-08T13:30:44.752821+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-a94597d8f0fa — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "afr", "rationale": "Conservative 1-to-1 mapping of trial Black/African American participants to gnomAD African/African American genetic ancestry group", "source": "gnomAD v4 ancestry definitions", "trial_category": "Black or African American", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:0; method: curated; retrieved: 2026-11-08T13:30:44.753275+00:00.

Source URL not provided.

Source note: Conservative 1-to-1 mapping of trial Black/African American participants to gnomAD African/African American genetic ancestry group

**Fact F-b119d67d1311 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "nfe", "rationale": "Conservative 1-to-1 mapping of trial White participants to gnomAD non-Finnish European genetic ancestry group", "source": "gnomAD v4 ancestry definitions", "trial_category": "White", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:1; method: curated; retrieved: 2026-11-08T13:30:44.753839+00:00.

Source URL not provided.

Source note: Conservative 1-to-1 mapping of trial White participants to gnomAD non-Finnish European genetic ancestry group

**Fact F-5366663e00fb — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "eas", "rationale": "In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics", "source": "CPIC Global Allele Frequency Data", "trial_category": "Asian", "weight": 0.6}
```

Source: GeneGap.mapping; record: A:2; method: curated; retrieved: 2026-11-08T13:30:44.754474+00:00.

Source URL not provided.

Source note: In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics

**Fact F-41d2fdc6e017 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "sas", "rationale": "In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics", "source": "CPIC Global Allele Frequency Data", "trial_category": "Asian", "weight": 0.4}
```

Source: GeneGap.mapping; record: A:3; method: curated; retrieved: 2026-11-08T13:30:44.755081+00:00.

Source URL not provided.

Source note: In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics

**Fact F-fdc78c982461 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "ami", "rationale": "Direct mapping to gnomAD Indigenous American ancestry group", "source": "gnomAD v4 Indigenous American cohort", "trial_category": "American Indian or Alaska Native", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:4; method: curated; retrieved: 2026-11-08T13:30:44.755617+00:00.

Source URL not provided.

Source note: Direct mapping to gnomAD Indigenous American ancestry group

**Fact F-a95fae356884 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Currently no isolated Pacific Islander cohort in gnomAD v4; mapped to remaining with low confidence flag", "source": "gnomAD v4 population groups", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:5; method: curated; retrieved: 2026-11-08T13:30:44.756114+00:00.

Source URL not provided.

Source note: Currently no isolated Pacific Islander cohort in gnomAD v4; mapped to remaining with low confidence flag

**Fact F-8c2993ee938b — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "amr", "rationale": "Admixed American population in gnomAD reflecting diverse Latin American and Hispanic ancestry", "source": "gnomAD v4 Admixed American definitions", "trial_category": "Hispanic or Latino", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:6; method: curated; retrieved: 2026-11-08T13:30:44.756629+00:00.

Source URL not provided.

Source note: Admixed American population in gnomAD reflecting diverse Latin American and Hispanic ancestry

**Fact F-33542d6ec3d4 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Mixed ancestry without specific proportions reported by trial; evaluated under admixture sensitivity model", "source": "gnomAD v4 population groups", "trial_category": "More than one race", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:7; method: curated; retrieved: 2026-11-08T13:30:44.757090+00:00.

Source URL not provided.

Source note: Mixed ancestry without specific proportions reported by trial; evaluated under admixture sensitivity model

**Fact F-7a175210b780 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic group. Tracked explicitly as missing trial demographic data", "source": "FDA Demographic Rule & GeneGap Missing Data Protocol", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: A:8; method: curated; retrieved: 2026-11-08T13:30:44.757475+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic group. Tracked explicitly as missing trial demographic data

**Fact F-f43aff3f7e20 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "afr", "rationale": "Admixture-aware version: most US participants identifying as Black or African American carry substantial non-African ancestry. Weight is a structural placeholder until a cited study replaces it.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Black or African American", "weight": 0.85}
```

Source: GeneGap.mapping; record: B:0; method: curated; retrieved: 2026-11-08T13:30:44.757905+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: most US participants identifying as Black or African American carry substantial non-African ancestry. Weight is a structural placeholder until a cited study replaces it.

**Fact F-9a046df0939e — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "nfe", "rationale": "Residual European ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Black or African American", "weight": 0.15}
```

Source: GeneGap.mapping; record: B:1; method: curated; retrieved: 2026-11-08T13:30:44.758399+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Residual European ancestry component. Placeholder weight.

**Fact F-ee9a7718f927 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "nfe", "rationale": "Admixture-aware version: participants identifying as White are not exclusively non-Finnish European. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.9}
```

Source: GeneGap.mapping; record: B:2; method: curated; retrieved: 2026-11-08T13:30:44.758965+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: participants identifying as White are not exclusively non-Finnish European. Placeholder weight.

**Fact F-7c09e76d1fc2 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "fin", "rationale": "Finnish ancestry is reported separately by gnomAD. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.03}
```

Source: GeneGap.mapping; record: B:3; method: curated; retrieved: 2026-11-08T13:30:44.759425+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Finnish ancestry is reported separately by gnomAD. Placeholder weight.

**Fact F-adf9cf9e266d — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "asj", "rationale": "Ashkenazi Jewish ancestry is reported separately by gnomAD. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.04}
```

Source: GeneGap.mapping; record: B:4; method: curated; retrieved: 2026-11-08T13:30:44.759856+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Ashkenazi Jewish ancestry is reported separately by gnomAD. Placeholder weight.

**Fact F-a4273d3aa3e2 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "mid", "rationale": "Middle Eastern ancestry is frequently recorded as White on US trial forms. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.03}
```

Source: GeneGap.mapping; record: B:5; method: curated; retrieved: 2026-11-08T13:30:44.760419+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Middle Eastern ancestry is frequently recorded as White on US trial forms. Placeholder weight.

**Fact F-5d2928aa7dc3 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "eas", "rationale": "Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.", "source": "PLACEHOLDER - needs trial-country breakdown ([MED] D2)", "trial_category": "Asian", "weight": 0.5}
```

Source: GeneGap.mapping; record: B:6; method: curated; retrieved: 2026-11-08T13:30:44.760865+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.

**Fact F-1f6ef9380535 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "sas", "rationale": "Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.", "source": "PLACEHOLDER - needs trial-country breakdown ([MED] D2)", "trial_category": "Asian", "weight": 0.5}
```

Source: GeneGap.mapping; record: B:7; method: curated; retrieved: 2026-11-08T13:30:44.761284+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.

**Fact F-17d94a8d44d3 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "ami", "rationale": "Admixture-aware version: gnomAD ami is an Amish cohort and is a poor proxy. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.7}
```

Source: GeneGap.mapping; record: B:8; method: curated; retrieved: 2026-11-08T13:30:44.761784+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: gnomAD ami is an Amish cohort and is a poor proxy. Placeholder weight.

**Fact F-f59a2d816c6b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Part of this category is better represented by the Admixed American group. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.3}
```

Source: GeneGap.mapping; record: B:9; method: curated; retrieved: 2026-11-08T13:30:44.762276+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Part of this category is better represented by the Admixed American group. Placeholder weight.

**Fact F-8b6143337b21 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "gnomAD v4 has no Pacific Islander group. Placeholder weight.", "source": "PLACEHOLDER - no Pacific Islander cohort in gnomAD v4", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.7}
```

Source: GeneGap.mapping; record: B:10; method: curated; retrieved: 2026-11-08T13:30:44.762760+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. gnomAD v4 has no Pacific Islander group. Placeholder weight.

**Fact F-f6b9a1a71532 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Partial East Asian ancestry component. Placeholder weight.", "source": "PLACEHOLDER - no Pacific Islander cohort in gnomAD v4", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.3}
```

Source: GeneGap.mapping; record: B:11; method: curated; retrieved: 2026-11-08T13:30:44.763386+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Partial East Asian ancestry component. Placeholder weight.

**Fact F-75971e836a89 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "amr", "rationale": "Hispanic or Latino ancestry is highly variable; this version keeps most weight on amr with European and African components. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.8}
```

Source: GeneGap.mapping; record: B:12; method: curated; retrieved: 2026-11-08T13:30:44.764002+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Hispanic or Latino ancestry is highly variable; this version keeps most weight on amr with European and African components. Placeholder weight.

**Fact F-6193346a98a0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "European ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.12}
```

Source: GeneGap.mapping; record: B:13; method: curated; retrieved: 2026-11-08T13:30:44.764545+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. European ancestry component. Placeholder weight.

**Fact F-1a4d8290645f — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "African ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.08}
```

Source: GeneGap.mapping; record: B:14; method: curated; retrieved: 2026-11-08T13:30:44.764987+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. African ancestry component. Placeholder weight.

**Fact F-d801b8e299d8 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Mixed ancestry with unreported components. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.6}
```

Source: GeneGap.mapping; record: B:15; method: curated; retrieved: 2026-11-08T13:30:44.765418+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Mixed ancestry with unreported components. Placeholder weight.

**Fact F-4838901c32e5 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Admixed American component. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: B:16; method: curated; retrieved: 2026-11-08T13:30:44.765931+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixed American component. Placeholder weight.

**Fact F-d999ffd4f514 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "European component. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: B:17; method: curated; retrieved: 2026-11-08T13:30:44.766389+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. European component. Placeholder weight.

**Fact F-90de285fe388 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.", "source": "GeneGap missing-data protocol (D2)", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: B:18; method: curated; retrieved: 2026-11-08T13:30:44.766852+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.

**Fact F-dff1c8538733 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test: widest plausible spread. These weights are not an estimate of reality; they exist to test whether a finding survives an extreme mapping.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.6}
```

Source: GeneGap.mapping; record: C:0; method: curated; retrieved: 2026-11-08T13:30:44.767287+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread. These weights are not an estimate of reality; they exist to test whether a finding survives an extreme mapping.

**Fact F-e4d3127bc88b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.25}
```

Source: GeneGap.mapping; record: C:1; method: curated; retrieved: 2026-11-08T13:30:44.767700+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-49fdc419d2a9 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.15}
```

Source: GeneGap.mapping; record: C:2; method: curated; retrieved: 2026-11-08T13:30:44.768272+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e3de003f2136 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test: widest plausible spread.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.7}
```

Source: GeneGap.mapping; record: C:3; method: curated; retrieved: 2026-11-08T13:30:44.768937+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread.

**Fact F-ac3792b4a7d0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "fin", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:4; method: curated; retrieved: 2026-11-08T13:30:44.769531+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e5a7d9e1fc49 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "asj", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:5; method: curated; retrieved: 2026-11-08T13:30:44.770060+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-aaabaaad3c9c — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "mid", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:6; method: curated; retrieved: 2026-11-08T13:30:44.770624+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-12a72f5fa447 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test: the opposite extreme to version A's 60/40 East Asian split.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Asian", "weight": 0.25}
```

Source: GeneGap.mapping; record: C:7; method: curated; retrieved: 2026-11-08T13:30:44.771462+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: the opposite extreme to version A's 60/40 East Asian split.

**Fact F-f3172b718bcb — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "sas", "rationale": "Stress test: South Asian dominant split.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Asian", "weight": 0.75}
```

Source: GeneGap.mapping; record: C:8; method: curated; retrieved: 2026-11-08T13:30:44.771918+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: South Asian dominant split.

**Fact F-47394cb233fd — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test: treats the category as predominantly Admixed American.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.8}
```

Source: GeneGap.mapping; record: C:9; method: curated; retrieved: 2026-11-08T13:30:44.772363+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: treats the category as predominantly Admixed American.

**Fact F-bf0ade33b67b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "ami", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:10; method: curated; retrieved: 2026-11-08T13:30:44.772800+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-85f9336dd5c1 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test: no Pacific Islander cohort exists in gnomAD v4.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:11; method: curated; retrieved: 2026-11-08T13:30:44.773227+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: no Pacific Islander cohort exists in gnomAD v4.

**Fact F-af3c66ea9892 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:12; method: curated; retrieved: 2026-11-08T13:30:44.773618+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-0a32bf99a858 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test: widest plausible spread for a highly variable category.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:13; method: curated; retrieved: 2026-11-08T13:30:44.774018+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread for a highly variable category.

**Fact F-1a6c8ab011f0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.3}
```

Source: GeneGap.mapping; record: C:14; method: curated; retrieved: 2026-11-08T13:30:44.774437+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-87dcbbed9441 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:15; method: curated; retrieved: 2026-11-08T13:30:44.774914+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-7cfdc0a2f9cf — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Stress test: components are never reported by trials.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.4}
```

Source: GeneGap.mapping; record: C:16; method: curated; retrieved: 2026-11-08T13:30:44.775326+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: components are never reported by trials.

**Fact F-458dc3231028 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:17; method: curated; retrieved: 2026-11-08T13:30:44.775728+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e43a3c3322e9 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:18; method: curated; retrieved: 2026-11-08T13:30:44.776150+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-b1e7afd8ad51 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:19; method: curated; retrieved: 2026-11-08T13:30:44.776588+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-fde7721260bc — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.", "source": "GeneGap missing-data protocol (D2)", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: C:20; method: curated; retrieved: 2026-11-08T13:30:44.777095+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.

**Fact F-c8a8636a7338 — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The trial data maps nobody to: amr, although the target population includes these groups.", "The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 1.26750658501581, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 1.2293546020300978, "expected_carriers": 756.9007805485037, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 2329.0, "prob_fewer_than_k": 0.0, "required_n": 93, "target_share": 0.13, "trial_share": 0.15981609826391271}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 146.0, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.010018527413710286}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.0, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.0, "expected_carriers": 0.0, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 139, "target_share": 0.18, "trial_share": 0.0}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 122, "target_share": null, "trial_share": 0.0}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.033959815759977044, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.03293762437384203, "expected_carriers": 12.360635146352273, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 24.0, "prob_fewer_than_k": 0.12121717438131821, "required_n": 59, "target_share": 0.05, "trial_share": 0.0016468812186921018}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 94, "target_share": null, "trial_share": 0.0}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 146, "target_share": null, "trial_share": 0.0}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.4073277815809935, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.3649671767423774, "expected_carriers": 3235.595160158267, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 11935.0, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.8189803060454265}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.435110139424706, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.42201331228985106, "expected_carriers": 37.04435132112077, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 123.0, "prob_fewer_than_k": 5.906693209093745e-10, "required_n": 100, "target_share": 0.02, "trial_share": 0.008440266245797022}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.05659969293329508, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.054896040623070054, "expected_carriers": 8.6083464703541, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 16.0, "prob_fewer_than_k": 0.6699441424150812, "required_n": 56, "target_share": 0.02, "trial_share": 0.0010979208124614012}], "inheritance": "dominant", "mapping_version": "A", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:A; method: computed; retrieved: 2026-11-08T13:30:44.811505+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The trial data maps nobody to: amr, although the target population includes these groups. The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-26bb9eb5dc88 — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 1.0823908937957165, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 1.0449514117255831, "expected_carriers": 643.365663466228, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 1979.6499999999999, "prob_fewer_than_k": 0.0, "required_n": 93, "target_share": 0.13, "trial_share": 0.13584368352432583}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 102.19999999999999, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.007012969189597201}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.017295800742759836, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.016697545689517146, "expected_carriers": 9.52096724631897, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 43.8, "prob_fewer_than_k": 0.5045692213261437, "required_n": 139, "target_share": 0.18, "trial_share": 0.003005558224113086}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 118.04763112422721, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 477.40000000000003, "prob_fewer_than_k": 2.2135395426542072e-45, "required_n": 122, "target_share": null, "trial_share": 0.03275921224181706}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.08088748456956449, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.07808961778631716, "expected_carriers": 29.305005826143514, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 56.9, "prob_fewer_than_k": 2.265639199866795e-08, "required_n": 59, "target_share": 0.05, "trial_share": 0.0039044808893158585}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 114.31418240472257, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 358.05, "prob_fewer_than_k": 4.481323492858098e-46, "required_n": 94, "target_share": null, "trial_share": 0.024569409181362797}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 73.7699605550635, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 358.05, "prob_fewer_than_k": 1.9162976424687183e-24, "required_n": 146, "target_share": null, "trial_share": 0.024569409181362797}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.3138707648482049, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.2684244836341183, "expected_carriers": 3006.7449168027915, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 11090.85, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.7610546901804709}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.3059935158804703, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.29540931860289577, "expected_carriers": 25.93104592478454, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 86.1, "prob_fewer_than_k": 1.3105166257994806e-05, "required_n": 100, "target_share": 0.02, "trial_share": 0.005908186372057916}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.07107863318942398, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.0686200507788376, "expected_carriers": 10.760433087942625, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 20.0, "prob_fewer_than_k": 0.28517164570263553, "required_n": 56, "target_share": 0.02, "trial_share": 0.0013724010155767518}], "inheritance": "dominant", "mapping_version": "B", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:B; method: computed; retrieved: 2026-11-08T13:30:44.818267+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-c4ed1377c5ff — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 0.775577213269676, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 0.7376127612180586, "expected_carriers": 454.1404683291022, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 1397.3999999999999, "prob_fewer_than_k": 2.7003141966092542e-219, "required_n": 93, "target_share": 0.13, "trial_share": 0.09588965895834763}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 29.200000000000003, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.0020037054827420574}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.18685332814725658, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.17770687039197297, "expected_carriers": 101.32874159524174, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 466.15, "prob_fewer_than_k": 6.962854051221955e-37, "required_n": 139, "target_share": 0.18, "trial_share": 0.031987236670555134}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 295.119077810568, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 3.0548698977556544e-130, "required_n": 122, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.10317718902735995, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.09812667261373774, "expected_carriers": 36.824392206841146, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 71.5, "prob_fewer_than_k": 3.955338797572064e-12, "required_n": 59, "target_share": 0.05, "trial_share": 0.004906333630686887}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 381.04727468240856, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 5.505619853235287e-181, "required_n": 94, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 245.89986851687834, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 1.67727965034696e-103, "required_n": 146, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.0746721958511178, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.0220670646629613, "expected_carriers": 2422.765399878039, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 8936.75, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.6132402387977767}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.22186703234904326, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.21100665614492553, "expected_carriers": 18.522175660560386, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 61.5, "prob_fewer_than_k": 0.0036565532051273213, "required_n": 100, "target_share": 0.02, "trial_share": 0.004220133122898511}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.10822782065806989, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.10293007616825638, "expected_carriers": 16.140649631913938, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 30.0, "prob_fewer_than_k": 0.007288996623613486, "required_n": 56, "target_share": 0.02, "trial_share": 0.0020586015233651275}], "inheritance": "dominant", "mapping_version": "C", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:C; method: computed; retrieved: 2026-11-08T13:30:44.825122+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

### Variant 10-94781859-G-A

For clopidogrel, trial coverage of CYP2C19 rs4244285 in group remaining suggests lower expected-carrier representation under mappings A, B and C, subject to mapping and target-population denominator assumptions. This is a draft coverage hypothesis.

Evidence tier: Not graded.

Citations: None supplied.

Mapping robustness: Reported as surviving all evaluated mappings.

Review status: draft.
No human review is recorded for this version of the finding.

Supporting source records:

**Fact F-e77c3dc56ed5 — ac\_an:afr**

```json
{"ac": 11987, "an": 67188, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.796834+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-fd96593d59de — ac\_an:ami**

```json
{"ac": 166, "an": 910, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.797445+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-9c590cde7fac — ac\_an:amr**

```json
{"ac": 4023, "an": 34880, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.798177+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-62e788dbfd9a — ac\_an:asj**

```json
{"ac": 3323, "an": 25098, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.798601+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-a8b8cb8c25ab — ac\_an:eas**

```json
{"ac": 11167, "an": 36782, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799010+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-17fdaf953b67 — ac\_an:fin**

```json
{"ac": 10733, "an": 61354, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799498+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-bbf212e3af8a — ac\_an:mid**

```json
{"ac": 611, "an": 5608, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799908+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-2386f33e2c84 — ac\_an:nfe**

```json
{"ac": 162522, "an": 1111304, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.800317+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-9b20fe7bdc51 — ac\_an:remaining**

```json
{"ac": 9207, "an": 56126, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.800811+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-ed42d2d17eeb — ac\_an:sas**

```json
{"ac": 20947, "an": 65396, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.801247+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-195ad34b1e99 — classification**

```json
{"classification": "drug response", "title": "NM_000769.4(CYP2C19):c.681G>T (p.Pro227=)"}
```

Source: ClinVar; record: VCV/uid:1703261; method: api; retrieved: 2026-11-08T13:30:44.802021+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/1703261/>)

**Fact F-f7a5bdb65dd2 — classification**

```json
{"classification": "drug response", "title": "CYP2C19*2/*2"}
```

Source: ClinVar; record: VCV/uid:638797; method: api; retrieved: 2026-11-08T13:30:44.802401+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/638797/>)

**Fact F-25ce0d369075 — classification**

```json
{"classification": "drug response", "title": "CYP2C19*2/*23"}
```

Source: ClinVar; record: VCV/uid:634407; method: api; retrieved: 2026-11-08T13:30:44.802776+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/634407/>)

**Fact F-4e63fd24c36c — overall\_status**

```json
"COMPLETED"
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.786117+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842>)

**Fact F-d661bf8179ea — baseline:sex:Female**

```json
{"basis": "total_row", "count": 287}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.788823+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-f4fb328ee136 — baseline:sex:Male**

```json
{"basis": "total_row", "count": 14286}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.789267+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-0ded459e81e8 — baseline:race:American Indian or Alaska Native**

```json
{"basis": "total_row", "count": 146}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.789751+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-351ee3cb9cd5 — baseline:race:Asian**

```json
{"basis": "total_row", "count": 40}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.790226+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-49d7e83055ff — baseline:race:Native Hawaiian or Other Pacific Islander**

```json
{"basis": "total_row", "count": 123}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.790659+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-440224b7c4ce — baseline:race:Black or African American**

```json
{"basis": "total_row", "count": 2329}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791146+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-997b44cb3a84 — baseline:race:White**

```json
{"basis": "total_row", "count": 11935}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791574+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-ed3f57076aa8 — baseline:race:More than one race**

```json
{"basis": "total_row", "count": 0}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791995+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-4eb5e4253bfb — baseline:race:Unknown or Not Reported**

```json
{"basis": "total_row", "count": 0}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.792509+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-c4dd55286720 — pooled\_race\_counts**

```json
{"counts": {"American Indian or Alaska Native": 146, "Asian": 40, "Black or African American": 2329, "More than one race": 0, "Native Hawaiian or Other Pacific Islander": 123, "Unknown or Not Reported": 0, "White": 11935}, "fact_ids": ["F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb"], "nct_ids": ["NCT01609842"]}
```

Source: GeneGap.trials; record: run-0b86b3c9fe5a479cbf434dcf35f2304b; method: computed; retrieved: 2026-11-08T13:30:44.793280+00:00.

Source URL not provided.

Source note: Found 3 completed trials with results; reading the first 3. NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939). NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076). 1 of 1 trials report a race breakdown.

**Fact F-f9d3360d4f0d — gene\_rule**

```json
{"assessable": true, "function_note": "Variant list comes from config/variant_details_CYP2C19.csv (medical student)", "gene": "CYP2C19", "inheritance": "dominant", "min_af": 0.005, "min_an": 5000, "reason_if_not": "", "rsids": [], "source": "https://www.ncbi.nlm.nih.gov/books/NBK84114/table/clopidogrel.Te/", "verified_by": "medical student (variant_details_CYP2C19.csv)"}
```

Source: GeneGap.variants; record: CYP2C19; method: curated; retrieved: 2026-11-08T13:30:44.803567+00:00.

Source URL not provided.

Source note: Variant list comes from config/variant\_details\_CYP2C19.csv (medical student)

**Fact F-c8651cb724b1 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure. Must be replaced with a national registry or audit before any result is reported.", "geography": "United States", "gnomad_group": "nfe", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.6, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:nfe; method: curated; retrieved: 2026-11-08T13:30:44.750284+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. Must be replaced with a national registry or audit before any result is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-d918cfb0b6c1 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "afr", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.13, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:afr; method: curated; retrieved: 2026-11-08T13:30:44.750935+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-b6971ee78767 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "amr", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.18, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:amr; method: curated; retrieved: 2026-11-08T13:30:44.751397+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-0162d73c2d7b — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "eas", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.05, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:eas; method: curated; retrieved: 2026-11-08T13:30:44.751852+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-39108d870da2 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "sas", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.02, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:sas; method: curated; retrieved: 2026-11-08T13:30:44.752290+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-7060fef065dd — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "remaining", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.02, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:remaining; method: curated; retrieved: 2026-11-08T13:30:44.752821+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-a94597d8f0fa — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "afr", "rationale": "Conservative 1-to-1 mapping of trial Black/African American participants to gnomAD African/African American genetic ancestry group", "source": "gnomAD v4 ancestry definitions", "trial_category": "Black or African American", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:0; method: curated; retrieved: 2026-11-08T13:30:44.753275+00:00.

Source URL not provided.

Source note: Conservative 1-to-1 mapping of trial Black/African American participants to gnomAD African/African American genetic ancestry group

**Fact F-b119d67d1311 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "nfe", "rationale": "Conservative 1-to-1 mapping of trial White participants to gnomAD non-Finnish European genetic ancestry group", "source": "gnomAD v4 ancestry definitions", "trial_category": "White", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:1; method: curated; retrieved: 2026-11-08T13:30:44.753839+00:00.

Source URL not provided.

Source note: Conservative 1-to-1 mapping of trial White participants to gnomAD non-Finnish European genetic ancestry group

**Fact F-5366663e00fb — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "eas", "rationale": "In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics", "source": "CPIC Global Allele Frequency Data", "trial_category": "Asian", "weight": 0.6}
```

Source: GeneGap.mapping; record: A:2; method: curated; retrieved: 2026-11-08T13:30:44.754474+00:00.

Source URL not provided.

Source note: In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics

**Fact F-41d2fdc6e017 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "sas", "rationale": "In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics", "source": "CPIC Global Allele Frequency Data", "trial_category": "Asian", "weight": 0.4}
```

Source: GeneGap.mapping; record: A:3; method: curated; retrieved: 2026-11-08T13:30:44.755081+00:00.

Source URL not provided.

Source note: In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics

**Fact F-fdc78c982461 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "ami", "rationale": "Direct mapping to gnomAD Indigenous American ancestry group", "source": "gnomAD v4 Indigenous American cohort", "trial_category": "American Indian or Alaska Native", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:4; method: curated; retrieved: 2026-11-08T13:30:44.755617+00:00.

Source URL not provided.

Source note: Direct mapping to gnomAD Indigenous American ancestry group

**Fact F-a95fae356884 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Currently no isolated Pacific Islander cohort in gnomAD v4; mapped to remaining with low confidence flag", "source": "gnomAD v4 population groups", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:5; method: curated; retrieved: 2026-11-08T13:30:44.756114+00:00.

Source URL not provided.

Source note: Currently no isolated Pacific Islander cohort in gnomAD v4; mapped to remaining with low confidence flag

**Fact F-8c2993ee938b — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "amr", "rationale": "Admixed American population in gnomAD reflecting diverse Latin American and Hispanic ancestry", "source": "gnomAD v4 Admixed American definitions", "trial_category": "Hispanic or Latino", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:6; method: curated; retrieved: 2026-11-08T13:30:44.756629+00:00.

Source URL not provided.

Source note: Admixed American population in gnomAD reflecting diverse Latin American and Hispanic ancestry

**Fact F-33542d6ec3d4 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Mixed ancestry without specific proportions reported by trial; evaluated under admixture sensitivity model", "source": "gnomAD v4 population groups", "trial_category": "More than one race", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:7; method: curated; retrieved: 2026-11-08T13:30:44.757090+00:00.

Source URL not provided.

Source note: Mixed ancestry without specific proportions reported by trial; evaluated under admixture sensitivity model

**Fact F-7a175210b780 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic group. Tracked explicitly as missing trial demographic data", "source": "FDA Demographic Rule & GeneGap Missing Data Protocol", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: A:8; method: curated; retrieved: 2026-11-08T13:30:44.757475+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic group. Tracked explicitly as missing trial demographic data

**Fact F-f43aff3f7e20 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "afr", "rationale": "Admixture-aware version: most US participants identifying as Black or African American carry substantial non-African ancestry. Weight is a structural placeholder until a cited study replaces it.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Black or African American", "weight": 0.85}
```

Source: GeneGap.mapping; record: B:0; method: curated; retrieved: 2026-11-08T13:30:44.757905+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: most US participants identifying as Black or African American carry substantial non-African ancestry. Weight is a structural placeholder until a cited study replaces it.

**Fact F-9a046df0939e — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "nfe", "rationale": "Residual European ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Black or African American", "weight": 0.15}
```

Source: GeneGap.mapping; record: B:1; method: curated; retrieved: 2026-11-08T13:30:44.758399+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Residual European ancestry component. Placeholder weight.

**Fact F-ee9a7718f927 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "nfe", "rationale": "Admixture-aware version: participants identifying as White are not exclusively non-Finnish European. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.9}
```

Source: GeneGap.mapping; record: B:2; method: curated; retrieved: 2026-11-08T13:30:44.758965+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: participants identifying as White are not exclusively non-Finnish European. Placeholder weight.

**Fact F-7c09e76d1fc2 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "fin", "rationale": "Finnish ancestry is reported separately by gnomAD. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.03}
```

Source: GeneGap.mapping; record: B:3; method: curated; retrieved: 2026-11-08T13:30:44.759425+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Finnish ancestry is reported separately by gnomAD. Placeholder weight.

**Fact F-adf9cf9e266d — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "asj", "rationale": "Ashkenazi Jewish ancestry is reported separately by gnomAD. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.04}
```

Source: GeneGap.mapping; record: B:4; method: curated; retrieved: 2026-11-08T13:30:44.759856+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Ashkenazi Jewish ancestry is reported separately by gnomAD. Placeholder weight.

**Fact F-a4273d3aa3e2 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "mid", "rationale": "Middle Eastern ancestry is frequently recorded as White on US trial forms. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.03}
```

Source: GeneGap.mapping; record: B:5; method: curated; retrieved: 2026-11-08T13:30:44.760419+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Middle Eastern ancestry is frequently recorded as White on US trial forms. Placeholder weight.

**Fact F-5d2928aa7dc3 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "eas", "rationale": "Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.", "source": "PLACEHOLDER - needs trial-country breakdown ([MED] D2)", "trial_category": "Asian", "weight": 0.5}
```

Source: GeneGap.mapping; record: B:6; method: curated; retrieved: 2026-11-08T13:30:44.760865+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.

**Fact F-1f6ef9380535 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "sas", "rationale": "Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.", "source": "PLACEHOLDER - needs trial-country breakdown ([MED] D2)", "trial_category": "Asian", "weight": 0.5}
```

Source: GeneGap.mapping; record: B:7; method: curated; retrieved: 2026-11-08T13:30:44.761284+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.

**Fact F-17d94a8d44d3 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "ami", "rationale": "Admixture-aware version: gnomAD ami is an Amish cohort and is a poor proxy. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.7}
```

Source: GeneGap.mapping; record: B:8; method: curated; retrieved: 2026-11-08T13:30:44.761784+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: gnomAD ami is an Amish cohort and is a poor proxy. Placeholder weight.

**Fact F-f59a2d816c6b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Part of this category is better represented by the Admixed American group. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.3}
```

Source: GeneGap.mapping; record: B:9; method: curated; retrieved: 2026-11-08T13:30:44.762276+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Part of this category is better represented by the Admixed American group. Placeholder weight.

**Fact F-8b6143337b21 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "gnomAD v4 has no Pacific Islander group. Placeholder weight.", "source": "PLACEHOLDER - no Pacific Islander cohort in gnomAD v4", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.7}
```

Source: GeneGap.mapping; record: B:10; method: curated; retrieved: 2026-11-08T13:30:44.762760+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. gnomAD v4 has no Pacific Islander group. Placeholder weight.

**Fact F-f6b9a1a71532 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Partial East Asian ancestry component. Placeholder weight.", "source": "PLACEHOLDER - no Pacific Islander cohort in gnomAD v4", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.3}
```

Source: GeneGap.mapping; record: B:11; method: curated; retrieved: 2026-11-08T13:30:44.763386+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Partial East Asian ancestry component. Placeholder weight.

**Fact F-75971e836a89 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "amr", "rationale": "Hispanic or Latino ancestry is highly variable; this version keeps most weight on amr with European and African components. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.8}
```

Source: GeneGap.mapping; record: B:12; method: curated; retrieved: 2026-11-08T13:30:44.764002+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Hispanic or Latino ancestry is highly variable; this version keeps most weight on amr with European and African components. Placeholder weight.

**Fact F-6193346a98a0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "European ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.12}
```

Source: GeneGap.mapping; record: B:13; method: curated; retrieved: 2026-11-08T13:30:44.764545+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. European ancestry component. Placeholder weight.

**Fact F-1a4d8290645f — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "African ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.08}
```

Source: GeneGap.mapping; record: B:14; method: curated; retrieved: 2026-11-08T13:30:44.764987+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. African ancestry component. Placeholder weight.

**Fact F-d801b8e299d8 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Mixed ancestry with unreported components. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.6}
```

Source: GeneGap.mapping; record: B:15; method: curated; retrieved: 2026-11-08T13:30:44.765418+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Mixed ancestry with unreported components. Placeholder weight.

**Fact F-4838901c32e5 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Admixed American component. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: B:16; method: curated; retrieved: 2026-11-08T13:30:44.765931+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixed American component. Placeholder weight.

**Fact F-d999ffd4f514 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "European component. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: B:17; method: curated; retrieved: 2026-11-08T13:30:44.766389+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. European component. Placeholder weight.

**Fact F-90de285fe388 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.", "source": "GeneGap missing-data protocol (D2)", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: B:18; method: curated; retrieved: 2026-11-08T13:30:44.766852+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.

**Fact F-dff1c8538733 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test: widest plausible spread. These weights are not an estimate of reality; they exist to test whether a finding survives an extreme mapping.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.6}
```

Source: GeneGap.mapping; record: C:0; method: curated; retrieved: 2026-11-08T13:30:44.767287+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread. These weights are not an estimate of reality; they exist to test whether a finding survives an extreme mapping.

**Fact F-e4d3127bc88b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.25}
```

Source: GeneGap.mapping; record: C:1; method: curated; retrieved: 2026-11-08T13:30:44.767700+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-49fdc419d2a9 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.15}
```

Source: GeneGap.mapping; record: C:2; method: curated; retrieved: 2026-11-08T13:30:44.768272+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e3de003f2136 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test: widest plausible spread.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.7}
```

Source: GeneGap.mapping; record: C:3; method: curated; retrieved: 2026-11-08T13:30:44.768937+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread.

**Fact F-ac3792b4a7d0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "fin", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:4; method: curated; retrieved: 2026-11-08T13:30:44.769531+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e5a7d9e1fc49 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "asj", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:5; method: curated; retrieved: 2026-11-08T13:30:44.770060+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-aaabaaad3c9c — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "mid", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:6; method: curated; retrieved: 2026-11-08T13:30:44.770624+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-12a72f5fa447 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test: the opposite extreme to version A's 60/40 East Asian split.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Asian", "weight": 0.25}
```

Source: GeneGap.mapping; record: C:7; method: curated; retrieved: 2026-11-08T13:30:44.771462+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: the opposite extreme to version A's 60/40 East Asian split.

**Fact F-f3172b718bcb — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "sas", "rationale": "Stress test: South Asian dominant split.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Asian", "weight": 0.75}
```

Source: GeneGap.mapping; record: C:8; method: curated; retrieved: 2026-11-08T13:30:44.771918+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: South Asian dominant split.

**Fact F-47394cb233fd — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test: treats the category as predominantly Admixed American.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.8}
```

Source: GeneGap.mapping; record: C:9; method: curated; retrieved: 2026-11-08T13:30:44.772363+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: treats the category as predominantly Admixed American.

**Fact F-bf0ade33b67b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "ami", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:10; method: curated; retrieved: 2026-11-08T13:30:44.772800+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-85f9336dd5c1 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test: no Pacific Islander cohort exists in gnomAD v4.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:11; method: curated; retrieved: 2026-11-08T13:30:44.773227+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: no Pacific Islander cohort exists in gnomAD v4.

**Fact F-af3c66ea9892 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:12; method: curated; retrieved: 2026-11-08T13:30:44.773618+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-0a32bf99a858 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test: widest plausible spread for a highly variable category.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:13; method: curated; retrieved: 2026-11-08T13:30:44.774018+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread for a highly variable category.

**Fact F-1a6c8ab011f0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.3}
```

Source: GeneGap.mapping; record: C:14; method: curated; retrieved: 2026-11-08T13:30:44.774437+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-87dcbbed9441 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:15; method: curated; retrieved: 2026-11-08T13:30:44.774914+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-7cfdc0a2f9cf — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Stress test: components are never reported by trials.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.4}
```

Source: GeneGap.mapping; record: C:16; method: curated; retrieved: 2026-11-08T13:30:44.775326+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: components are never reported by trials.

**Fact F-458dc3231028 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:17; method: curated; retrieved: 2026-11-08T13:30:44.775728+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e43a3c3322e9 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:18; method: curated; retrieved: 2026-11-08T13:30:44.776150+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-b1e7afd8ad51 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:19; method: curated; retrieved: 2026-11-08T13:30:44.776588+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-fde7721260bc — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.", "source": "GeneGap missing-data protocol (D2)", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: C:20; method: curated; retrieved: 2026-11-08T13:30:44.777095+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.

**Fact F-c8a8636a7338 — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The trial data maps nobody to: amr, although the target population includes these groups.", "The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 1.26750658501581, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 1.2293546020300978, "expected_carriers": 756.9007805485037, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 2329.0, "prob_fewer_than_k": 0.0, "required_n": 93, "target_share": 0.13, "trial_share": 0.15981609826391271}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 146.0, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.010018527413710286}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.0, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.0, "expected_carriers": 0.0, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 139, "target_share": 0.18, "trial_share": 0.0}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 122, "target_share": null, "trial_share": 0.0}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.033959815759977044, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.03293762437384203, "expected_carriers": 12.360635146352273, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 24.0, "prob_fewer_than_k": 0.12121717438131821, "required_n": 59, "target_share": 0.05, "trial_share": 0.0016468812186921018}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 94, "target_share": null, "trial_share": 0.0}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 146, "target_share": null, "trial_share": 0.0}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.4073277815809935, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.3649671767423774, "expected_carriers": 3235.595160158267, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 11935.0, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.8189803060454265}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.435110139424706, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.42201331228985106, "expected_carriers": 37.04435132112077, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 123.0, "prob_fewer_than_k": 5.906693209093745e-10, "required_n": 100, "target_share": 0.02, "trial_share": 0.008440266245797022}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.05659969293329508, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.054896040623070054, "expected_carriers": 8.6083464703541, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 16.0, "prob_fewer_than_k": 0.6699441424150812, "required_n": 56, "target_share": 0.02, "trial_share": 0.0010979208124614012}], "inheritance": "dominant", "mapping_version": "A", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:A; method: computed; retrieved: 2026-11-08T13:30:44.811505+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The trial data maps nobody to: amr, although the target population includes these groups. The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-26bb9eb5dc88 — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 1.0823908937957165, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 1.0449514117255831, "expected_carriers": 643.365663466228, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 1979.6499999999999, "prob_fewer_than_k": 0.0, "required_n": 93, "target_share": 0.13, "trial_share": 0.13584368352432583}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 102.19999999999999, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.007012969189597201}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.017295800742759836, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.016697545689517146, "expected_carriers": 9.52096724631897, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 43.8, "prob_fewer_than_k": 0.5045692213261437, "required_n": 139, "target_share": 0.18, "trial_share": 0.003005558224113086}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 118.04763112422721, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 477.40000000000003, "prob_fewer_than_k": 2.2135395426542072e-45, "required_n": 122, "target_share": null, "trial_share": 0.03275921224181706}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.08088748456956449, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.07808961778631716, "expected_carriers": 29.305005826143514, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 56.9, "prob_fewer_than_k": 2.265639199866795e-08, "required_n": 59, "target_share": 0.05, "trial_share": 0.0039044808893158585}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 114.31418240472257, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 358.05, "prob_fewer_than_k": 4.481323492858098e-46, "required_n": 94, "target_share": null, "trial_share": 0.024569409181362797}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 73.7699605550635, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 358.05, "prob_fewer_than_k": 1.9162976424687183e-24, "required_n": 146, "target_share": null, "trial_share": 0.024569409181362797}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.3138707648482049, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.2684244836341183, "expected_carriers": 3006.7449168027915, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 11090.85, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.7610546901804709}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.3059935158804703, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.29540931860289577, "expected_carriers": 25.93104592478454, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 86.1, "prob_fewer_than_k": 1.3105166257994806e-05, "required_n": 100, "target_share": 0.02, "trial_share": 0.005908186372057916}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.07107863318942398, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.0686200507788376, "expected_carriers": 10.760433087942625, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 20.0, "prob_fewer_than_k": 0.28517164570263553, "required_n": 56, "target_share": 0.02, "trial_share": 0.0013724010155767518}], "inheritance": "dominant", "mapping_version": "B", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:B; method: computed; retrieved: 2026-11-08T13:30:44.818267+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-c4ed1377c5ff — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 0.775577213269676, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 0.7376127612180586, "expected_carriers": 454.1404683291022, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 1397.3999999999999, "prob_fewer_than_k": 2.7003141966092542e-219, "required_n": 93, "target_share": 0.13, "trial_share": 0.09588965895834763}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 29.200000000000003, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.0020037054827420574}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.18685332814725658, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.17770687039197297, "expected_carriers": 101.32874159524174, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 466.15, "prob_fewer_than_k": 6.962854051221955e-37, "required_n": 139, "target_share": 0.18, "trial_share": 0.031987236670555134}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 295.119077810568, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 3.0548698977556544e-130, "required_n": 122, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.10317718902735995, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.09812667261373774, "expected_carriers": 36.824392206841146, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 71.5, "prob_fewer_than_k": 3.955338797572064e-12, "required_n": 59, "target_share": 0.05, "trial_share": 0.004906333630686887}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 381.04727468240856, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 5.505619853235287e-181, "required_n": 94, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 245.89986851687834, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 1.67727965034696e-103, "required_n": 146, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.0746721958511178, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.0220670646629613, "expected_carriers": 2422.765399878039, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 8936.75, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.6132402387977767}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.22186703234904326, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.21100665614492553, "expected_carriers": 18.522175660560386, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 61.5, "prob_fewer_than_k": 0.0036565532051273213, "required_n": 100, "target_share": 0.02, "trial_share": 0.004220133122898511}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.10822782065806989, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.10293007616825638, "expected_carriers": 16.140649631913938, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 30.0, "prob_fewer_than_k": 0.007288996623613486, "required_n": 56, "target_share": 0.02, "trial_share": 0.0020586015233651275}], "inheritance": "dominant", "mapping_version": "C", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:C; method: computed; retrieved: 2026-11-08T13:30:44.825122+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

### Variant 10-94781859-G-A

For clopidogrel, trial coverage of CYP2C19 rs4244285 in group sas suggests lower expected-carrier representation under mappings A, B and C, subject to mapping and target-population denominator assumptions. This is a draft coverage hypothesis.

Evidence tier: Not graded.

Citations: None supplied.

Mapping robustness: Reported as surviving all evaluated mappings.

Review status: draft.
No human review is recorded for this version of the finding.

Supporting source records:

**Fact F-e77c3dc56ed5 — ac\_an:afr**

```json
{"ac": 11987, "an": 67188, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.796834+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-fd96593d59de — ac\_an:ami**

```json
{"ac": 166, "an": 910, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.797445+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-9c590cde7fac — ac\_an:amr**

```json
{"ac": 4023, "an": 34880, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.798177+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-62e788dbfd9a — ac\_an:asj**

```json
{"ac": 3323, "an": 25098, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.798601+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-a8b8cb8c25ab — ac\_an:eas**

```json
{"ac": 11167, "an": 36782, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799010+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-17fdaf953b67 — ac\_an:fin**

```json
{"ac": 10733, "an": 61354, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799498+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-bbf212e3af8a — ac\_an:mid**

```json
{"ac": 611, "an": 5608, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.799908+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-2386f33e2c84 — ac\_an:nfe**

```json
{"ac": 162522, "an": 1111304, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.800317+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-9b20fe7bdc51 — ac\_an:remaining**

```json
{"ac": 9207, "an": 56126, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.800811+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-ed42d2d17eeb — ac\_an:sas**

```json
{"ac": 20947, "an": 65396, "dataset": "gnomad_r4"}
```

Source: gnomAD; record: 10-94781859-G-A; method: api; retrieved: 2026-11-08T13:30:44.801247+00:00.

[Open source](<https://gnomad.broadinstitute.org/variant/10-94781859-G-A?dataset=gnomad_r4>)

**Fact F-195ad34b1e99 — classification**

```json
{"classification": "drug response", "title": "NM_000769.4(CYP2C19):c.681G>T (p.Pro227=)"}
```

Source: ClinVar; record: VCV/uid:1703261; method: api; retrieved: 2026-11-08T13:30:44.802021+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/1703261/>)

**Fact F-f7a5bdb65dd2 — classification**

```json
{"classification": "drug response", "title": "CYP2C19*2/*2"}
```

Source: ClinVar; record: VCV/uid:638797; method: api; retrieved: 2026-11-08T13:30:44.802401+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/638797/>)

**Fact F-25ce0d369075 — classification**

```json
{"classification": "drug response", "title": "CYP2C19*2/*23"}
```

Source: ClinVar; record: VCV/uid:634407; method: api; retrieved: 2026-11-08T13:30:44.802776+00:00.

[Open source](<https://www.ncbi.nlm.nih.gov/clinvar/variation/634407/>)

**Fact F-4e63fd24c36c — overall\_status**

```json
"COMPLETED"
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.786117+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842>)

**Fact F-d661bf8179ea — baseline:sex:Female**

```json
{"basis": "total_row", "count": 287}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.788823+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-f4fb328ee136 — baseline:sex:Male**

```json
{"basis": "total_row", "count": 14286}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.789267+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-0ded459e81e8 — baseline:race:American Indian or Alaska Native**

```json
{"basis": "total_row", "count": 146}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.789751+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-351ee3cb9cd5 — baseline:race:Asian**

```json
{"basis": "total_row", "count": 40}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.790226+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-49d7e83055ff — baseline:race:Native Hawaiian or Other Pacific Islander**

```json
{"basis": "total_row", "count": 123}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.790659+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-440224b7c4ce — baseline:race:Black or African American**

```json
{"basis": "total_row", "count": 2329}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791146+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-997b44cb3a84 — baseline:race:White**

```json
{"basis": "total_row", "count": 11935}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791574+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-ed3f57076aa8 — baseline:race:More than one race**

```json
{"basis": "total_row", "count": 0}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.791995+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-4eb5e4253bfb — baseline:race:Unknown or Not Reported**

```json
{"basis": "total_row", "count": 0}
```

Source: ClinicalTrials.gov; record: NCT01609842; method: api; retrieved: 2026-11-08T13:30:44.792509+00:00.

[Open source](<https://clinicaltrials.gov/study/NCT01609842?tab=results>)

Source note: Read from the posted baseline table using the 'total\_row' column rule.

**Fact F-c4dd55286720 — pooled\_race\_counts**

```json
{"counts": {"American Indian or Alaska Native": 146, "Asian": 40, "Black or African American": 2329, "More than one race": 0, "Native Hawaiian or Other Pacific Islander": 123, "Unknown or Not Reported": 0, "White": 11935}, "fact_ids": ["F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb"], "nct_ids": ["NCT01609842"]}
```

Source: GeneGap.trials; record: run-0b86b3c9fe5a479cbf434dcf35f2304b; method: computed; retrieved: 2026-11-08T13:30:44.793280+00:00.

Source URL not provided.

Source note: Found 3 completed trials with results; reading the first 3. NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939). NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076). 1 of 1 trials report a race breakdown.

**Fact F-f9d3360d4f0d — gene\_rule**

```json
{"assessable": true, "function_note": "Variant list comes from config/variant_details_CYP2C19.csv (medical student)", "gene": "CYP2C19", "inheritance": "dominant", "min_af": 0.005, "min_an": 5000, "reason_if_not": "", "rsids": [], "source": "https://www.ncbi.nlm.nih.gov/books/NBK84114/table/clopidogrel.Te/", "verified_by": "medical student (variant_details_CYP2C19.csv)"}
```

Source: GeneGap.variants; record: CYP2C19; method: curated; retrieved: 2026-11-08T13:30:44.803567+00:00.

Source URL not provided.

Source note: Variant list comes from config/variant\_details\_CYP2C19.csv (medical student)

**Fact F-c8651cb724b1 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure. Must be replaced with a national registry or audit before any result is reported.", "geography": "United States", "gnomad_group": "nfe", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.6, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:nfe; method: curated; retrieved: 2026-11-08T13:30:44.750284+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. Must be replaced with a national registry or audit before any result is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-d918cfb0b6c1 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "afr", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.13, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:afr; method: curated; retrieved: 2026-11-08T13:30:44.750935+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-b6971ee78767 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "amr", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.18, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:amr; method: curated; retrieved: 2026-11-08T13:30:44.751397+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-0162d73c2d7b — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "eas", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.05, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:eas; method: curated; retrieved: 2026-11-08T13:30:44.751852+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-39108d870da2 — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "sas", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.02, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:sas; method: curated; retrieved: 2026-11-08T13:30:44.752290+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-7060fef065dd — target\_population\_row**

```json
{"basis": "assumption", "caveat": "Structural placeholder share. Not a cited figure.", "geography": "United States", "gnomad_group": "remaining", "label": "US adults receiving antiplatelet therapy after acute coronary syndrome", "population_id": "us_acs_antiplatelet", "quote": "", "share": 0.02, "source": "PLACEHOLDER - [MED] D5: replace with a cited disease-burden source", "year": ""}
```

Source: GeneGap.population; record: us\_acs\_antiplatelet:remaining; method: curated; retrieved: 2026-11-08T13:30:44.752821+00:00.

Source URL not provided.

Source note: Structural placeholder share. Not a cited figure. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-a94597d8f0fa — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "afr", "rationale": "Conservative 1-to-1 mapping of trial Black/African American participants to gnomAD African/African American genetic ancestry group", "source": "gnomAD v4 ancestry definitions", "trial_category": "Black or African American", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:0; method: curated; retrieved: 2026-11-08T13:30:44.753275+00:00.

Source URL not provided.

Source note: Conservative 1-to-1 mapping of trial Black/African American participants to gnomAD African/African American genetic ancestry group

**Fact F-b119d67d1311 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "nfe", "rationale": "Conservative 1-to-1 mapping of trial White participants to gnomAD non-Finnish European genetic ancestry group", "source": "gnomAD v4 ancestry definitions", "trial_category": "White", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:1; method: curated; retrieved: 2026-11-08T13:30:44.753839+00:00.

Source URL not provided.

Source note: Conservative 1-to-1 mapping of trial White participants to gnomAD non-Finnish European genetic ancestry group

**Fact F-5366663e00fb — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "eas", "rationale": "In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics", "source": "CPIC Global Allele Frequency Data", "trial_category": "Asian", "weight": 0.6}
```

Source: GeneGap.mapping; record: A:2; method: curated; retrieved: 2026-11-08T13:30:44.754474+00:00.

Source URL not provided.

Source note: In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics

**Fact F-41d2fdc6e017 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "sas", "rationale": "In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics", "source": "CPIC Global Allele Frequency Data", "trial_category": "Asian", "weight": 0.4}
```

Source: GeneGap.mapping; record: A:3; method: curated; retrieved: 2026-11-08T13:30:44.755081+00:00.

Source URL not provided.

Source note: In Version A conservative model Asian is assigned 60% East Asian (eas) and 40% South Asian (sas) based on global clinical trial enrollment demographics

**Fact F-fdc78c982461 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "ami", "rationale": "Direct mapping to gnomAD Indigenous American ancestry group", "source": "gnomAD v4 Indigenous American cohort", "trial_category": "American Indian or Alaska Native", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:4; method: curated; retrieved: 2026-11-08T13:30:44.755617+00:00.

Source URL not provided.

Source note: Direct mapping to gnomAD Indigenous American ancestry group

**Fact F-a95fae356884 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Currently no isolated Pacific Islander cohort in gnomAD v4; mapped to remaining with low confidence flag", "source": "gnomAD v4 population groups", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:5; method: curated; retrieved: 2026-11-08T13:30:44.756114+00:00.

Source URL not provided.

Source note: Currently no isolated Pacific Islander cohort in gnomAD v4; mapped to remaining with low confidence flag

**Fact F-8c2993ee938b — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "amr", "rationale": "Admixed American population in gnomAD reflecting diverse Latin American and Hispanic ancestry", "source": "gnomAD v4 Admixed American definitions", "trial_category": "Hispanic or Latino", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:6; method: curated; retrieved: 2026-11-08T13:30:44.756629+00:00.

Source URL not provided.

Source note: Admixed American population in gnomAD reflecting diverse Latin American and Hispanic ancestry

**Fact F-33542d6ec3d4 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Mixed ancestry without specific proportions reported by trial; evaluated under admixture sensitivity model", "source": "gnomAD v4 population groups", "trial_category": "More than one race", "weight": 1.0}
```

Source: GeneGap.mapping; record: A:7; method: curated; retrieved: 2026-11-08T13:30:44.757090+00:00.

Source URL not provided.

Source note: Mixed ancestry without specific proportions reported by trial; evaluated under admixture sensitivity model

**Fact F-7a175210b780 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic group. Tracked explicitly as missing trial demographic data", "source": "FDA Demographic Rule & GeneGap Missing Data Protocol", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: A:8; method: curated; retrieved: 2026-11-08T13:30:44.757475+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic group. Tracked explicitly as missing trial demographic data

**Fact F-f43aff3f7e20 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "afr", "rationale": "Admixture-aware version: most US participants identifying as Black or African American carry substantial non-African ancestry. Weight is a structural placeholder until a cited study replaces it.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Black or African American", "weight": 0.85}
```

Source: GeneGap.mapping; record: B:0; method: curated; retrieved: 2026-11-08T13:30:44.757905+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: most US participants identifying as Black or African American carry substantial non-African ancestry. Weight is a structural placeholder until a cited study replaces it.

**Fact F-9a046df0939e — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "nfe", "rationale": "Residual European ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Black or African American", "weight": 0.15}
```

Source: GeneGap.mapping; record: B:1; method: curated; retrieved: 2026-11-08T13:30:44.758399+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Residual European ancestry component. Placeholder weight.

**Fact F-ee9a7718f927 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "nfe", "rationale": "Admixture-aware version: participants identifying as White are not exclusively non-Finnish European. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.9}
```

Source: GeneGap.mapping; record: B:2; method: curated; retrieved: 2026-11-08T13:30:44.758965+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: participants identifying as White are not exclusively non-Finnish European. Placeholder weight.

**Fact F-7c09e76d1fc2 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "fin", "rationale": "Finnish ancestry is reported separately by gnomAD. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.03}
```

Source: GeneGap.mapping; record: B:3; method: curated; retrieved: 2026-11-08T13:30:44.759425+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Finnish ancestry is reported separately by gnomAD. Placeholder weight.

**Fact F-adf9cf9e266d — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "asj", "rationale": "Ashkenazi Jewish ancestry is reported separately by gnomAD. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.04}
```

Source: GeneGap.mapping; record: B:4; method: curated; retrieved: 2026-11-08T13:30:44.759856+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Ashkenazi Jewish ancestry is reported separately by gnomAD. Placeholder weight.

**Fact F-a4273d3aa3e2 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "mid", "rationale": "Middle Eastern ancestry is frequently recorded as White on US trial forms. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "White", "weight": 0.03}
```

Source: GeneGap.mapping; record: B:5; method: curated; retrieved: 2026-11-08T13:30:44.760419+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Middle Eastern ancestry is frequently recorded as White on US trial forms. Placeholder weight.

**Fact F-5d2928aa7dc3 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "eas", "rationale": "Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.", "source": "PLACEHOLDER - needs trial-country breakdown ([MED] D2)", "trial_category": "Asian", "weight": 0.5}
```

Source: GeneGap.mapping; record: B:6; method: curated; retrieved: 2026-11-08T13:30:44.760865+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.

**Fact F-1f6ef9380535 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "sas", "rationale": "Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.", "source": "PLACEHOLDER - needs trial-country breakdown ([MED] D2)", "trial_category": "Asian", "weight": 0.5}
```

Source: GeneGap.mapping; record: B:7; method: curated; retrieved: 2026-11-08T13:30:44.761284+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Asian means different things by country: this version splits it evenly pending a country-aware rule. Placeholder weight.

**Fact F-17d94a8d44d3 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "ami", "rationale": "Admixture-aware version: gnomAD ami is an Amish cohort and is a poor proxy. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.7}
```

Source: GeneGap.mapping; record: B:8; method: curated; retrieved: 2026-11-08T13:30:44.761784+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixture-aware version: gnomAD ami is an Amish cohort and is a poor proxy. Placeholder weight.

**Fact F-f59a2d816c6b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Part of this category is better represented by the Admixed American group. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.3}
```

Source: GeneGap.mapping; record: B:9; method: curated; retrieved: 2026-11-08T13:30:44.762276+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Part of this category is better represented by the Admixed American group. Placeholder weight.

**Fact F-8b6143337b21 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "gnomAD v4 has no Pacific Islander group. Placeholder weight.", "source": "PLACEHOLDER - no Pacific Islander cohort in gnomAD v4", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.7}
```

Source: GeneGap.mapping; record: B:10; method: curated; retrieved: 2026-11-08T13:30:44.762760+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. gnomAD v4 has no Pacific Islander group. Placeholder weight.

**Fact F-f6b9a1a71532 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Partial East Asian ancestry component. Placeholder weight.", "source": "PLACEHOLDER - no Pacific Islander cohort in gnomAD v4", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.3}
```

Source: GeneGap.mapping; record: B:11; method: curated; retrieved: 2026-11-08T13:30:44.763386+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Partial East Asian ancestry component. Placeholder weight.

**Fact F-75971e836a89 — ancestry\_mapping\_row**

```json
{"confidence": "medium", "gnomad_group": "amr", "rationale": "Hispanic or Latino ancestry is highly variable; this version keeps most weight on amr with European and African components. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.8}
```

Source: GeneGap.mapping; record: B:12; method: curated; retrieved: 2026-11-08T13:30:44.764002+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Hispanic or Latino ancestry is highly variable; this version keeps most weight on amr with European and African components. Placeholder weight.

**Fact F-6193346a98a0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "European ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.12}
```

Source: GeneGap.mapping; record: B:13; method: curated; retrieved: 2026-11-08T13:30:44.764545+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. European ancestry component. Placeholder weight.

**Fact F-1a4d8290645f — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "African ancestry component. Placeholder weight.", "source": "PLACEHOLDER - needs a cited admixture study ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.08}
```

Source: GeneGap.mapping; record: B:14; method: curated; retrieved: 2026-11-08T13:30:44.764987+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. African ancestry component. Placeholder weight.

**Fact F-d801b8e299d8 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Mixed ancestry with unreported components. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.6}
```

Source: GeneGap.mapping; record: B:15; method: curated; retrieved: 2026-11-08T13:30:44.765418+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Mixed ancestry with unreported components. Placeholder weight.

**Fact F-4838901c32e5 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Admixed American component. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: B:16; method: curated; retrieved: 2026-11-08T13:30:44.765931+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Admixed American component. Placeholder weight.

**Fact F-d999ffd4f514 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "European component. Placeholder weight.", "source": "PLACEHOLDER - trials do not report the component races", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: B:17; method: curated; retrieved: 2026-11-08T13:30:44.766389+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. European component. Placeholder weight.

**Fact F-90de285fe388 — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.", "source": "GeneGap missing-data protocol (D2)", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: B:18; method: curated; retrieved: 2026-11-08T13:30:44.766852+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.

**Fact F-dff1c8538733 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test: widest plausible spread. These weights are not an estimate of reality; they exist to test whether a finding survives an extreme mapping.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.6}
```

Source: GeneGap.mapping; record: C:0; method: curated; retrieved: 2026-11-08T13:30:44.767287+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread. These weights are not an estimate of reality; they exist to test whether a finding survives an extreme mapping.

**Fact F-e4d3127bc88b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.25}
```

Source: GeneGap.mapping; record: C:1; method: curated; retrieved: 2026-11-08T13:30:44.767700+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-49fdc419d2a9 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Black or African American", "weight": 0.15}
```

Source: GeneGap.mapping; record: C:2; method: curated; retrieved: 2026-11-08T13:30:44.768272+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e3de003f2136 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test: widest plausible spread.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.7}
```

Source: GeneGap.mapping; record: C:3; method: curated; retrieved: 2026-11-08T13:30:44.768937+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread.

**Fact F-ac3792b4a7d0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "fin", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:4; method: curated; retrieved: 2026-11-08T13:30:44.769531+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e5a7d9e1fc49 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "asj", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:5; method: curated; retrieved: 2026-11-08T13:30:44.770060+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-aaabaaad3c9c — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "mid", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "White", "weight": 0.1}
```

Source: GeneGap.mapping; record: C:6; method: curated; retrieved: 2026-11-08T13:30:44.770624+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-12a72f5fa447 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test: the opposite extreme to version A's 60/40 East Asian split.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Asian", "weight": 0.25}
```

Source: GeneGap.mapping; record: C:7; method: curated; retrieved: 2026-11-08T13:30:44.771462+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: the opposite extreme to version A's 60/40 East Asian split.

**Fact F-f3172b718bcb — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "sas", "rationale": "Stress test: South Asian dominant split.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Asian", "weight": 0.75}
```

Source: GeneGap.mapping; record: C:8; method: curated; retrieved: 2026-11-08T13:30:44.771918+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: South Asian dominant split.

**Fact F-47394cb233fd — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test: treats the category as predominantly Admixed American.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.8}
```

Source: GeneGap.mapping; record: C:9; method: curated; retrieved: 2026-11-08T13:30:44.772363+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: treats the category as predominantly Admixed American.

**Fact F-bf0ade33b67b — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "ami", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "American Indian or Alaska Native", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:10; method: curated; retrieved: 2026-11-08T13:30:44.772800+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-85f9336dd5c1 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test: no Pacific Islander cohort exists in gnomAD v4.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:11; method: curated; retrieved: 2026-11-08T13:30:44.773227+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: no Pacific Islander cohort exists in gnomAD v4.

**Fact F-af3c66ea9892 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Native Hawaiian or Other Pacific Islander", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:12; method: curated; retrieved: 2026-11-08T13:30:44.773618+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-0a32bf99a858 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "amr", "rationale": "Stress test: widest plausible spread for a highly variable category.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.5}
```

Source: GeneGap.mapping; record: C:13; method: curated; retrieved: 2026-11-08T13:30:44.774018+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: widest plausible spread for a highly variable category.

**Fact F-1a6c8ab011f0 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.3}
```

Source: GeneGap.mapping; record: C:14; method: curated; retrieved: 2026-11-08T13:30:44.774437+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-87dcbbed9441 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "Hispanic or Latino", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:15; method: curated; retrieved: 2026-11-08T13:30:44.774914+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-7cfdc0a2f9cf — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "remaining", "rationale": "Stress test: components are never reported by trials.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.4}
```

Source: GeneGap.mapping; record: C:16; method: curated; retrieved: 2026-11-08T13:30:44.775326+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test: components are never reported by trials.

**Fact F-458dc3231028 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "afr", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:17; method: curated; retrieved: 2026-11-08T13:30:44.775728+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-e43a3c3322e9 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "eas", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:18; method: curated; retrieved: 2026-11-08T13:30:44.776150+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-b1e7afd8ad51 — ancestry\_mapping\_row**

```json
{"confidence": "low", "gnomad_group": "nfe", "rationale": "Stress test component.", "source": "PLACEHOLDER - deliberate stress test ([MED] D2)", "trial_category": "More than one race", "weight": 0.2}
```

Source: GeneGap.mapping; record: C:19; method: curated; retrieved: 2026-11-08T13:30:44.776588+00:00.

Source URL not provided.

Source note: PLACEHOLDER assumption; the weight requires a verified source. Stress test component.

**Fact F-fde7721260bc — ancestry\_mapping\_row**

```json
{"confidence": "high", "gnomad_group": "", "rationale": "Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.", "source": "GeneGap missing-data protocol (D2)", "trial_category": "Unknown or Not Reported", "weight": 0.0}
```

Source: GeneGap.mapping; record: C:20; method: curated; retrieved: 2026-11-08T13:30:44.777095+00:00.

Source URL not provided.

Source note: Never reassigned to any genetic ancestry group. Reported as a missing-data percentage.

**Fact F-c8a8636a7338 — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The trial data maps nobody to: amr, although the target population includes these groups.", "The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 1.26750658501581, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 1.2293546020300978, "expected_carriers": 756.9007805485037, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 2329.0, "prob_fewer_than_k": 0.0, "required_n": 93, "target_share": 0.13, "trial_share": 0.15981609826391271}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 146.0, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.010018527413710286}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.0, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.0, "expected_carriers": 0.0, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 139, "target_share": 0.18, "trial_share": 0.0}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 122, "target_share": null, "trial_share": 0.0}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.033959815759977044, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.03293762437384203, "expected_carriers": 12.360635146352273, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 24.0, "prob_fewer_than_k": 0.12121717438131821, "required_n": 59, "target_share": 0.05, "trial_share": 0.0016468812186921018}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 94, "target_share": null, "trial_share": 0.0}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 0.0, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 0.0, "prob_fewer_than_k": null, "required_n": 146, "target_share": null, "trial_share": 0.0}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.4073277815809935, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.3649671767423774, "expected_carriers": 3235.595160158267, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 11935.0, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.8189803060454265}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.435110139424706, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.42201331228985106, "expected_carriers": 37.04435132112077, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 123.0, "prob_fewer_than_k": 5.906693209093745e-10, "required_n": 100, "target_share": 0.02, "trial_share": 0.008440266245797022}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.05659969293329508, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.054896040623070054, "expected_carriers": 8.6083464703541, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 16.0, "prob_fewer_than_k": 0.6699441424150812, "required_n": 56, "target_share": 0.02, "trial_share": 0.0010979208124614012}], "inheritance": "dominant", "mapping_version": "A", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:A; method: computed; retrieved: 2026-11-08T13:30:44.811505+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The trial data maps nobody to: amr, although the target population includes these groups. The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-26bb9eb5dc88 — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 1.0823908937957165, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 1.0449514117255831, "expected_carriers": 643.365663466228, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 1979.6499999999999, "prob_fewer_than_k": 0.0, "required_n": 93, "target_share": 0.13, "trial_share": 0.13584368352432583}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 102.19999999999999, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.007012969189597201}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.017295800742759836, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.016697545689517146, "expected_carriers": 9.52096724631897, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 43.8, "prob_fewer_than_k": 0.5045692213261437, "required_n": 139, "target_share": 0.18, "trial_share": 0.003005558224113086}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 118.04763112422721, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 477.40000000000003, "prob_fewer_than_k": 2.2135395426542072e-45, "required_n": 122, "target_share": null, "trial_share": 0.03275921224181706}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.08088748456956449, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.07808961778631716, "expected_carriers": 29.305005826143514, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 56.9, "prob_fewer_than_k": 2.265639199866795e-08, "required_n": 59, "target_share": 0.05, "trial_share": 0.0039044808893158585}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 114.31418240472257, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 358.05, "prob_fewer_than_k": 4.481323492858098e-46, "required_n": 94, "target_share": null, "trial_share": 0.024569409181362797}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 73.7699605550635, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 358.05, "prob_fewer_than_k": 1.9162976424687183e-24, "required_n": 146, "target_share": null, "trial_share": 0.024569409181362797}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.3138707648482049, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.2684244836341183, "expected_carriers": 3006.7449168027915, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 11090.85, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.7610546901804709}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.3059935158804703, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.29540931860289577, "expected_carriers": 25.93104592478454, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 86.1, "prob_fewer_than_k": 1.3105166257994806e-05, "required_n": 100, "target_share": 0.02, "trial_share": 0.005908186372057916}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.07107863318942398, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.0686200507788376, "expected_carriers": 10.760433087942625, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 20.0, "prob_fewer_than_k": 0.28517164570263553, "required_n": 56, "target_share": 0.02, "trial_share": 0.0013724010155767518}], "inheritance": "dominant", "mapping_version": "B", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:B; method: computed; retrieved: 2026-11-08T13:30:44.818267+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

**Fact F-c4ed1377c5ff — gap\_result**

```json
{"notes": ["Found 3 completed trials with results; reading the first 3.", "NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).", "NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).", "1 of 1 trials report a race breakdown.", "Using 10 variants from the medical student's file for CYP2C19.", "rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'", "rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)", "gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.", "The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.", "Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.", "100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.", "Clinical evidence grading and independent critic review are pending."], "result": {"fact_ids": ["F-e77c3dc56ed5", "F-fd96593d59de", "F-9c590cde7fac", "F-62e788dbfd9a", "F-a8b8cb8c25ab", "F-17fdaf953b67", "F-bbf212e3af8a", "F-2386f33e2c84", "F-9b20fe7bdc51", "F-ed42d2d17eeb", "F-195ad34b1e99", "F-f7a5bdb65dd2", "F-25ce0d369075", "F-4e63fd24c36c", "F-d661bf8179ea", "F-f4fb328ee136", "F-0ded459e81e8", "F-351ee3cb9cd5", "F-49d7e83055ff", "F-440224b7c4ce", "F-997b44cb3a84", "F-ed3f57076aa8", "F-4eb5e4253bfb", "F-c4dd55286720", "F-f9d3360d4f0d", "F-c8651cb724b1", "F-d918cfb0b6c1", "F-b6971ee78767", "F-0162d73c2d7b", "F-39108d870da2", "F-7060fef065dd", "F-a94597d8f0fa", "F-b119d67d1311", "F-5366663e00fb", "F-41d2fdc6e017", "F-fdc78c982461", "F-a95fae356884", "F-8c2993ee938b", "F-33542d6ec3d4", "F-7a175210b780", "F-f43aff3f7e20", "F-9a046df0939e", "F-ee9a7718f927", "F-7c09e76d1fc2", "F-adf9cf9e266d", "F-a4273d3aa3e2", "F-5d2928aa7dc3", "F-1f6ef9380535", "F-17d94a8d44d3", "F-f59a2d816c6b", "F-8b6143337b21", "F-f6b9a1a71532", "F-75971e836a89", "F-6193346a98a0", "F-1a4d8290645f", "F-d801b8e299d8", "F-4838901c32e5", "F-d999ffd4f514", "F-90de285fe388", "F-dff1c8538733", "F-e4d3127bc88b", "F-49fdc419d2a9", "F-e3de003f2136", "F-ac3792b4a7d0", "F-e5a7d9e1fc49", "F-aaabaaad3c9c", "F-12a72f5fa447", "F-f3172b718bcb", "F-47394cb233fd", "F-bf0ade33b67b", "F-85f9336dd5c1", "F-af3c66ea9892", "F-0a32bf99a858", "F-1a6c8ab011f0", "F-87dcbbed9441", "F-7cfdc0a2f9cf", "F-458dc3231028", "F-e43a3c3322e9", "F-b1e7afd8ad51", "F-fde7721260bc"], "gene": "CYP2C19", "groups": [{"ac": 11987, "allele_freq": 0.17840983508959934, "an": 67188, "carrier_freq": 0.3249896009225005, "carrier_ratio": 0.775577213269676, "ci_high": 0.3298391878458244, "ci_low": 0.32024915190171493, "enrolment_ratio": 0.7376127612180586, "expected_carriers": 454.1404683291022, "group": "afr", "insufficient_data": false, "k_threshold": 10, "n_trial": 1397.3999999999999, "prob_fewer_than_k": 2.7003141966092542e-219, "required_n": 93, "target_share": 0.13, "trial_share": 0.09588965895834763}, {"ac": 166, "allele_freq": 0.1824175824175824, "an": 910, "carrier_freq": null, "carrier_ratio": null, "ci_high": null, "ci_low": null, "enrolment_ratio": null, "expected_carriers": null, "group": "ami", "insufficient_data": true, "k_threshold": 10, "n_trial": 29.200000000000003, "prob_fewer_than_k": null, "required_n": null, "target_share": null, "trial_share": 0.0020037054827420574}, {"ac": 4023, "allele_freq": 0.11533830275229358, "an": 34880, "carrier_freq": 0.21737368142280755, "carrier_ratio": 0.18685332814725658, "ci_high": 0.2234646139422573, "ci_low": 0.21151523730093033, "enrolment_ratio": 0.17770687039197297, "expected_carriers": 101.32874159524174, "group": "amr", "insufficient_data": false, "k_threshold": 10, "n_trial": 466.15, "prob_fewer_than_k": 6.962854051221955e-37, "required_n": 139, "target_share": 0.18, "trial_share": 0.031987236670555134}, {"ac": 3323, "allele_freq": 0.13240098812654394, "an": 25098, "carrier_freq": 0.24727195459620277, "carrier_ratio": null, "ci_high": 0.2547376989500139, "ci_low": 0.24015810444800267, "enrolment_ratio": null, "expected_carriers": 295.119077810568, "group": "asj", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 3.0548698977556544e-130, "required_n": 122, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 11167, "allele_freq": 0.30359958675439075, "an": 36782, "carrier_freq": 0.5150264644313447, "carrier_ratio": 0.10317718902735995, "ci_high": 0.5217223180334726, "ci_low": 0.5084637857764683, "enrolment_ratio": 0.09812667261373774, "expected_carriers": 36.824392206841146, "group": "eas", "insufficient_data": false, "k_threshold": 10, "n_trial": 71.5, "prob_fewer_than_k": 3.955338797572064e-12, "required_n": 59, "target_share": 0.05, "trial_share": 0.004906333630686887}, {"ac": 10733, "allele_freq": 0.17493561951950973, "an": 61354, "carrier_freq": 0.31926876806234483, "carrier_ratio": null, "ci_high": 0.3243319902790486, "ci_low": 0.3143281409994171, "enrolment_ratio": null, "expected_carriers": 381.04727468240856, "group": "fin", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 5.505619853235287e-181, "required_n": 94, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 611, "allele_freq": 0.10895149786019971, "an": 5608, "carrier_freq": 0.2060325668344184, "carrier_ratio": null, "ci_high": 0.22124737179912743, "ci_low": 0.19194421778683268, "enrolment_ratio": null, "expected_carriers": 245.89986851687834, "group": "mid", "insufficient_data": false, "k_threshold": 10, "n_trial": 1193.5, "prob_fewer_than_k": 1.67727965034696e-103, "required_n": 146, "target_share": null, "trial_share": 0.08189803060454265}, {"ac": 162522, "allele_freq": 0.146244411970082, "an": 1111304, "carrier_freq": 0.2711013959076889, "carrier_ratio": 1.0746721958511178, "ci_high": 0.2722401633553747, "ci_low": 0.2699846455479682, "enrolment_ratio": 1.0220670646629613, "expected_carriers": 2422.765399878039, "group": "nfe", "insufficient_data": false, "k_threshold": 10, "n_trial": 8936.75, "prob_fewer_than_k": 0.0, "required_n": 111, "target_share": 0.6, "trial_share": 0.6132402387977767}, {"ac": 9207, "allele_freq": 0.1640416206392759, "an": 56126, "carrier_freq": 0.30117358797659166, "carrier_ratio": 0.22186703234904326, "ci_high": 0.306397126270718, "ci_low": 0.2960840559822098, "enrolment_ratio": 0.21100665614492553, "expected_carriers": 18.522175660560386, "group": "remaining", "insufficient_data": false, "k_threshold": 10, "n_trial": 61.5, "prob_fewer_than_k": 0.0036565532051273213, "required_n": 100, "target_share": 0.02, "trial_share": 0.004220133122898511}, {"ac": 20947, "allele_freq": 0.32031011071013515, "an": 65396, "carrier_freq": 0.5380216543971312, "carrier_ratio": 0.10822782065806989, "ci_high": 0.5429732475219536, "ci_low": 0.5331187518069309, "enrolment_ratio": 0.10293007616825638, "expected_carriers": 16.140649631913938, "group": "sas", "insufficient_data": false, "k_threshold": 10, "n_trial": 30.0, "prob_fewer_than_k": 0.007288996623613486, "required_n": 56, "target_share": 0.02, "trial_share": 0.0020586015233651275}], "inheritance": "dominant", "mapping_version": "C", "variant_id": "10-94781859-G-A"}, "target_carriers": 30, "target_label": "US adults receiving antiplatelet therapy after acute coronary syndrome"}
```

Source: GeneGap.stats; record: run-0b86b3c9fe5a479cbf434dcf35f2304b:10-94781859-G-A:C; method: computed; retrieved: 2026-11-08T13:30:44.825122+00:00.

Source URL not provided.

Source note: Computed by genegap.gap.compute\_gap; gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency. The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded. Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported. 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

## Limits and assumptions

Self-identified trial race and ethnicity and genetic ancestry are different measures. Their mapping is an explicit assumption.

Carrier estimates do not predict individual drug response. Missing evidence does not establish safety.

Report author's context notes (outside per-finding approval):

- These are draft coverage hypotheses. Clinical evidence grading and an independent critic review are pending; no finding has human approval.

- 100% of this target population is an ASSUMPTION taken from the general population mix, not from disease-burden data. Treat the representation ratios as indicative.

- Black or African American -&gt; afr: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Black or African American -&gt; nfe: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- White -&gt; nfe: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- White -&gt; fin: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- White -&gt; asj: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- White -&gt; mid: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Asian -&gt; eas: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Asian -&gt; sas: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- American Indian or Alaska Native -&gt; ami: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- American Indian or Alaska Native -&gt; amr: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Native Hawaiian or Other Pacific Islander -&gt; remaining: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Native Hawaiian or Other Pacific Islander -&gt; eas: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Hispanic or Latino -&gt; amr: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Hispanic or Latino -&gt; nfe: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Hispanic or Latino -&gt; afr: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- More than one race -&gt; remaining: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- More than one race -&gt; amr: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- More than one race -&gt; nfe: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Black or African American -&gt; amr: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- More than one race -&gt; afr: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- More than one race -&gt; eas: weight has no citation and is marked PLACEHOLDER. It must be sourced before any result is reported.

- Offline mode replays the recorded clopidogrel/CYP2C19 responses; other records are unavailable unless already cached.

- Found 3 completed trials with results; reading the first 3.

- NCT01511939: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT01511939).

- NCT00687076: could not fetch the full record (ClinicalTrials.gov: offline mode and no cached response for https://clinicaltrials.gov/api/v2/studies/NCT00687076).

- 1 of 1 trials report a race breakdown.

- Mapping B: 18 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.

- Mapping C: 20 weights are marked PLACEHOLDER and carry no citation (American Indian or Alaska Native, Asian, Black or African American, Hispanic or Latino, More than one race, Native Hawaiian or Other Pacific Islander, White). They must be sourced before any result based on this mapping is reported.

- Using 10 variants from the medical student's file for CYP2C19.

- rs4244285: allele 10-94781859-G-T could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs4244285: allele 10-94781859-G-C could not be fetched (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs4244285 / 10-94781859-G-A: kept: 32.03% in 'sas'

- rs4986893: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs12248560: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs28399504: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs56337013: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs72552267: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs72558186: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs41291556: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs17884712: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- rs6413438: gnomAD lookup failed (gnomAD: offline mode and no cached response for https://gnomad.broadinstitute.org/api)

- gnomAD has fewer than 5000 alleles for: ami. These groups are reported as insufficient data rather than given a frequency.

- The trial data maps nobody to: amr, although the target population includes these groups.

- The target population table has no share for: ami, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.

- The target population table has no share for: ami, asj, fin, mid, so no representation ratio can be formed for them even though the mapping places participants there. Either add them to the table or say why they are excluded.
